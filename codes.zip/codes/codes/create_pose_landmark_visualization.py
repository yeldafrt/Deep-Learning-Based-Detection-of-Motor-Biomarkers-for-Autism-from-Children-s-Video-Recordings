import cv2
import mediapipe as mp
import numpy as np
import os
import pandas as pd
from datetime import datetime

# Create output directory
output_dir = '/home/ubuntu/pose_landmark_visualization'
os.makedirs(output_dir, exist_ok=True)

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# Custom drawing specs for better visibility
custom_connections = [(mp_pose.PoseLandmark.LEFT_SHOULDER, mp_pose.PoseLandmark.LEFT_ELBOW),
                     (mp_pose.PoseLandmark.LEFT_ELBOW, mp_pose.PoseLandmark.LEFT_WRIST),
                     (mp_pose.PoseLandmark.RIGHT_SHOULDER, mp_pose.PoseLandmark.RIGHT_ELBOW),
                     (mp_pose.PoseLandmark.RIGHT_ELBOW, mp_pose.PoseLandmark.RIGHT_WRIST),
                     (mp_pose.PoseLandmark.NOSE, mp_pose.PoseLandmark.LEFT_SHOULDER),
                     (mp_pose.PoseLandmark.NOSE, mp_pose.PoseLandmark.RIGHT_SHOULDER),
                     (mp_pose.PoseLandmark.LEFT_SHOULDER, mp_pose.PoseLandmark.RIGHT_SHOULDER)]

# Custom landmark specs
landmark_drawing_spec = mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=6, circle_radius=3)
connection_drawing_spec = mp_drawing.DrawingSpec(color=(255, 0, 0), thickness=4)

# Load the video
video_path = '/home/ubuntu/upload/Kathrynshowsusthearmflap.mp4'
cap = cv2.VideoCapture(video_path)

# Get video properties
fps = cap.get(cv2.CAP_PROP_FPS)
frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video FPS: {fps}")
print(f"Total frames: {total_frames}")
print(f"Frame dimensions: {frame_width}x{frame_height}")

# Select frames at regular intervals to capture movement pattern
num_frames_to_extract = 10
frame_indices = np.linspace(0, total_frames-1, num_frames_to_extract, dtype=int)

print(f"Extracting frames at indices: {frame_indices}")

# Process frames
processed_frames = []
original_frames = []
frame_count = 0

with mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    model_complexity=2) as pose:
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
            
        if frame_count in frame_indices:
            print(f"Processing frame {frame_count}")
            
            # Save original frame
            original_frames.append(frame.copy())
            
            # Convert to RGB for MediaPipe
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Process with MediaPipe
            results = pose.process(frame_rgb)
            
            # Create visualization frame
            vis_frame = frame.copy()
            
            # Draw pose landmarks with custom style
            if results.pose_landmarks:
                # Draw landmarks with custom specs
                mp_drawing.draw_landmarks(
                    vis_frame,
                    results.pose_landmarks,
                    mp_pose.POSE_CONNECTIONS,
                    landmark_drawing_spec=landmark_drawing_spec,
                    connection_drawing_spec=connection_drawing_spec)
                
                # Add movement trajectory visualization
                # Focus on key landmarks for arm movement (shoulders, elbows, wrists)
                key_landmarks = [
                    mp_pose.PoseLandmark.LEFT_SHOULDER.value,
                    mp_pose.PoseLandmark.RIGHT_SHOULDER.value,
                    mp_pose.PoseLandmark.LEFT_ELBOW.value,
                    mp_pose.PoseLandmark.RIGHT_ELBOW.value,
                    mp_pose.PoseLandmark.LEFT_WRIST.value,
                    mp_pose.PoseLandmark.RIGHT_WRIST.value
                ]
                
                # Add frame number
                cv2.putText(vis_frame, f"Frame {frame_count}", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)
                
                # Add landmark labels
                landmarks = results.pose_landmarks.landmark
                for idx, landmark in enumerate(landmarks):
                    if idx in key_landmarks:
                        x = int(landmark.x * frame_width)
                        y = int(landmark.y * frame_height)
                        
                        # Get landmark name
                        landmark_name = mp_pose.PoseLandmark(idx).name.split('_')[-1]
                        cv2.putText(vis_frame, landmark_name, (x+10, y), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 2, cv2.LINE_AA)
            
            processed_frames.append(vis_frame)
            
            # Save individual frame
            cv2.imwrite(f"{output_dir}/frame_{frame_count}_landmarks.jpg", vis_frame)
            
        frame_count += 1
        
        if frame_count > max(frame_indices):
            break

cap.release()

# Create collage
rows = 2
cols = 5
collage_height = rows * frame_height
collage_width = cols * frame_width
collage = np.zeros((collage_height, collage_width, 3), dtype=np.uint8)

# Add frames to collage
for i, frame in enumerate(processed_frames):
    row = i // cols
    col = i % cols
    y_start = row * frame_height
    y_end = y_start + frame_height
    x_start = col * frame_width
    x_end = x_start + frame_width
    collage[y_start:y_end, x_start:x_end] = frame

# Save collage
collage_path = f"{output_dir}/pose_landmark_collage.jpg"
cv2.imwrite(collage_path, collage)
print(f"Collage saved to {collage_path}")

# Create a side-by-side comparison (original vs landmarks)
comparison_collage_height = 2 * rows * frame_height
comparison_collage_width = cols * frame_width
comparison_collage = np.zeros((comparison_collage_height, comparison_collage_width, 3), dtype=np.uint8)

# Add original frames to top rows
for i, frame in enumerate(original_frames):
    row = i // cols
    col = i % cols
    y_start = row * frame_height
    y_end = y_start + frame_height
    x_start = col * frame_width
    x_end = x_start + frame_width
    comparison_collage[y_start:y_end, x_start:x_end] = frame

# Add processed frames to bottom rows
for i, frame in enumerate(processed_frames):
    row = (i // cols) + rows
    col = i % cols
    y_start = row * frame_height
    y_end = y_start + frame_height
    x_start = col * frame_width
    x_end = x_start + frame_width
    comparison_collage[y_start:y_end, x_start:x_end] = frame

# Save comparison collage
comparison_path = f"{output_dir}/pose_landmark_comparison_collage.jpg"
cv2.imwrite(comparison_path, comparison_collage)
print(f"Comparison collage saved to {comparison_path}")

# Create an enhanced visualization with motion trails
motion_trail_frames = []

# Track positions of key landmarks across frames
landmark_positions = {
    'LEFT_WRIST': [],
    'RIGHT_WRIST': [],
    'LEFT_ELBOW': [],
    'RIGHT_ELBOW': []
}

# First pass to collect landmark positions
with mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    model_complexity=2) as pose:
    
    cap = cv2.VideoCapture(video_path)
    frame_count = 0
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
            
        if frame_count in frame_indices:
            # Convert to RGB for MediaPipe
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Process with MediaPipe
            results = pose.process(frame_rgb)
            
            if results.pose_landmarks:
                landmarks = results.pose_landmarks.landmark
                
                # Store positions of key landmarks
                if len(landmarks) > mp_pose.PoseLandmark.LEFT_WRIST.value:
                    lw = landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value]
                    landmark_positions['LEFT_WRIST'].append((int(lw.x * frame_width), int(lw.y * frame_height)))
                
                if len(landmarks) > mp_pose.PoseLandmark.RIGHT_WRIST.value:
                    rw = landmarks[mp_pose.PoseLandmark.RIGHT_WRIST.value]
                    landmark_positions['RIGHT_WRIST'].append((int(rw.x * frame_width), int(rw.y * frame_height)))
                
                if len(landmarks) > mp_pose.PoseLandmark.LEFT_ELBOW.value:
                    le = landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value]
                    landmark_positions['LEFT_ELBOW'].append((int(le.x * frame_width), int(le.y * frame_height)))
                
                if len(landmarks) > mp_pose.PoseLandmark.RIGHT_ELBOW.value:
                    re = landmarks[mp_pose.PoseLandmark.RIGHT_ELBOW.value]
                    landmark_positions['RIGHT_ELBOW'].append((int(re.x * frame_width), int(re.y * frame_height)))
        
        frame_count += 1
        
        if frame_count > max(frame_indices):
            break
    
    cap.release()

# Second pass to create motion trail visualization
cap = cv2.VideoCapture(video_path)
frame_count = 0
frame_idx_in_sequence = 0

with mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5,
    model_complexity=2) as pose:
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break
            
        if frame_count in frame_indices:
            # Convert to RGB for MediaPipe
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Process with MediaPipe
            results = pose.process(frame_rgb)
            
            # Create enhanced visualization
            enhanced_frame = frame.copy()
            
            # Draw motion trails
            for landmark_name, positions in landmark_positions.items():
                # Only draw trails up to current frame
                current_positions = positions[:frame_idx_in_sequence+1]
                
                # Draw trails with fading opacity
                for i in range(len(current_positions)-1):
                    # Calculate opacity based on recency (more recent = more opaque)
                    opacity = (i + 1) / len(current_positions)
                    color = (0, int(255 * opacity), int(255 * (1-opacity)))
                    thickness = max(1, int(3 * opacity))
                    
                    # Draw line segment
                    if i < len(current_positions)-1:
                        cv2.line(enhanced_frame, current_positions[i], current_positions[i+1], 
                                color, thickness)
            
            # Draw pose landmarks
            if results.pose_landmarks:
                mp_drawing.draw_landmarks(
                    enhanced_frame,
                    results.pose_landmarks,
                    mp_pose.POSE_CONNECTIONS,
                    landmark_drawing_spec=landmark_drawing_spec,
                    connection_drawing_spec=connection_drawing_spec)
            
            # Add frame number and title
            cv2.putText(enhanced_frame, f"Frame {frame_count}", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)
            
            motion_trail_frames.append(enhanced_frame)
            frame_idx_in_sequence += 1
            
            # Save individual enhanced frame
            cv2.imwrite(f"{output_dir}/frame_{frame_count}_enhanced.jpg", enhanced_frame)
        
        frame_count += 1
        
        if frame_count > max(frame_indices):
            break
    
    cap.release()

# Create motion trail collage
motion_trail_collage = np.zeros((collage_height, collage_width, 3), dtype=np.uint8)

# Add frames to collage
for i, frame in enumerate(motion_trail_frames):
    row = i // cols
    col = i % cols
    y_start = row * frame_height
    y_end = y_start + frame_height
    x_start = col * frame_width
    x_end = x_start + frame_width
    motion_trail_collage[y_start:y_end, x_start:x_end] = frame

# Save motion trail collage
motion_trail_path = f"{output_dir}/pose_landmark_motion_trail_collage.jpg"
cv2.imwrite(motion_trail_path, motion_trail_collage)
print(f"Motion trail collage saved to {motion_trail_path}")

# Create a final collage with frame numbers and labels
final_collage = motion_trail_collage.copy()

# Add frame numbers and labels
for i in range(len(motion_trail_frames)):
    row = i // cols
    col = i % cols
    y_pos = row * frame_height + 60
    x_pos = col * frame_width + 20
    
    # Add frame label
    cv2.putText(final_collage, f"Frame {frame_indices[i]}", (x_pos, y_pos), 
               cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3, cv2.LINE_AA)
    cv2.putText(final_collage, f"Frame {frame_indices[i]}", (x_pos, y_pos), 
               cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 2, cv2.LINE_AA)

# Add title
title = "Pose Landmark Visualization of Repetitive Movement Pattern in Autism"
cv2.putText(final_collage, title, (20, 40), 
           cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3, cv2.LINE_AA)
cv2.putText(final_collage, title, (20, 40), 
           cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 2, cv2.LINE_AA)

# Save final collage
final_path = f"{output_dir}/pose_landmark_final_collage.jpg"
cv2.imwrite(final_path, final_collage)
print(f"Final collage saved to {final_path}")
