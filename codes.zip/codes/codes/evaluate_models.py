import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc, precision_recall_curve
import pickle
import os

# Sonuçların kaydedileceği dizini oluştur
os.makedirs('/home/ubuntu/advanced_model/evaluation', exist_ok=True)

# Test sonuçlarını yükle
y_test = np.load('/home/ubuntu/advanced_model/results/y_test.npy')
ensemble_pred = np.load('/home/ubuntu/advanced_model/results/ensemble_pred.npy')
ensemble_pred_binary = np.load('/home/ubuntu/advanced_model/results/ensemble_pred_binary.npy')

# Önceki LSTM modelinin sonuçlarını yükle
lstm_y_test = np.load('/home/ubuntu/results/y_test.npy')
lstm_y_pred = np.load('/home/ubuntu/results/y_pred.npy')
lstm_y_pred_binary = (lstm_y_pred > 0.5).astype(int).flatten()

# Eğitim geçmişini yükle
with open('/home/ubuntu/advanced_model/results/bilstm_cnn_attention_history.pkl', 'rb') as f:
    bilstm_cnn_attention_history = pickle.load(f)

with open('/home/ubuntu/advanced_model/results/gru_history.pkl', 'rb') as f:
    gru_history = pickle.load(f)

with open('/home/ubuntu/advanced_model/results/cnn_history.pkl', 'rb') as f:
    cnn_history = pickle.load(f)

# Karmaşıklık matrisi hesaplama
def plot_confusion_matrix(y_true, y_pred, title, filename):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
    plt.title(title, fontsize=16)
    plt.ylabel('Gerçek Değer', fontsize=12)
    plt.xlabel('Tahmin Edilen Değer', fontsize=12)
    plt.xticks([0.5, 1.5], ['Sağlıklı (0)', 'Otizmli (1)'])
    plt.yticks([0.5, 1.5], ['Sağlıklı (0)', 'Otizmli (1)'])
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return cm

# ROC eğrisi çizme
def plot_roc_curve(y_true, y_pred_prob, title, filename):
    fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    
    plt.figure(figsize=(10, 8))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC eğrisi (AUC = {roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Yanlış Pozitif Oranı', fontsize=12)
    plt.ylabel('Doğru Pozitif Oranı', fontsize=12)
    plt.title(title, fontsize=16)
    plt.legend(loc="lower right", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return roc_auc

# Precision-Recall eğrisi çizme
def plot_precision_recall_curve(y_true, y_pred_prob, title, filename):
    precision, recall, _ = precision_recall_curve(y_true, y_pred_prob)
    pr_auc = auc(recall, precision)
    
    plt.figure(figsize=(10, 8))
    plt.plot(recall, precision, color='green', lw=2, label=f'PR eğrisi (AUC = {pr_auc:.3f})')
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title(title, fontsize=16)
    plt.legend(loc="lower left", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return pr_auc

# Eğitim geçmişi grafiği çizme
def plot_training_history(history, title, filename):
    plt.figure(figsize=(12, 10))
    
    plt.subplot(2, 2, 1)
    plt.plot(history['accuracy'], label='Eğitim')
    plt.plot(history['val_accuracy'], label='Validasyon')
    plt.title('Model Doğruluğu', fontsize=14)
    plt.ylabel('Doğruluk', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 2)
    plt.plot(history['loss'], label='Eğitim')
    plt.plot(history['val_loss'], label='Validasyon')
    plt.title('Model Kaybı', fontsize=14)
    plt.ylabel('Kayıp', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='upper right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 3)
    plt.plot(history['precision'], label='Eğitim')
    plt.plot(history['val_precision'], label='Validasyon')
    plt.title('Model Kesinliği (Precision)', fontsize=14)
    plt.ylabel('Kesinlik', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 4)
    plt.plot(history['recall'], label='Eğitim')
    plt.plot(history['val_recall'], label='Validasyon')
    plt.title('Model Duyarlılığı (Recall)', fontsize=14)
    plt.ylabel('Duyarlılık', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.suptitle(title, fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()

# Modelleri karşılaştırma grafiği
def plot_model_comparison(metrics_dict, title, filename):
    models = list(metrics_dict.keys())
    metrics = list(metrics_dict[models[0]].keys())
    
    x = np.arange(len(models))
    width = 0.15
    multiplier = 0
    
    fig, ax = plt.subplots(figsize=(14, 10))
    
    for metric in metrics:
        offset = width * multiplier
        rects = ax.bar(x + offset, [metrics_dict[model][metric] for model in models], width, label=metric)
        ax.bar_label(rects, fmt='%.2f', padding=3)
        multiplier += 1
    
    ax.set_ylabel('Değer', fontsize=14)
    ax.set_title(title, fontsize=16)
    ax.set_xticks(x + width * (len(metrics) - 1) / 2)
    ax.set_xticklabels(models, fontsize=12)
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), ncol=len(metrics), fontsize=12)
    ax.set_ylim(0, 1.15)
    ax.grid(True, linestyle='--', alpha=0.7, axis='y')
    
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()

# Ensemble model için karmaşıklık matrisi
print("Ensemble model için karmaşıklık matrisi hesaplanıyor...")
ensemble_cm = plot_confusion_matrix(
    y_test, 
    ensemble_pred_binary, 
    'Hibrit Ensemble Model - Karmaşıklık Matrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_confusion_matrix.png'
)

# LSTM model için karmaşıklık matrisi
print("LSTM model için karmaşıklık matrisi hesaplanıyor...")
lstm_cm = plot_confusion_matrix(
    lstm_y_test, 
    lstm_y_pred_binary, 
    'LSTM Model - Karmaşıklık Matrisi',
    '/home/ubuntu/advanced_model/evaluation/lstm_confusion_matrix.png'
)

# Ensemble model için ROC eğrisi
print("Ensemble model için ROC eğrisi çiziliyor...")
ensemble_roc_auc = plot_roc_curve(
    y_test, 
    ensemble_pred, 
    'Hibrit Ensemble Model - ROC Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_roc_curve.png'
)

# LSTM model için ROC eğrisi
print("LSTM model için ROC eğrisi çiziliyor...")
lstm_roc_auc = plot_roc_curve(
    lstm_y_test, 
    lstm_y_pred, 
    'LSTM Model - ROC Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/lstm_roc_curve.png'
)

# Ensemble model için Precision-Recall eğrisi
print("Ensemble model için Precision-Recall eğrisi çiziliyor...")
ensemble_pr_auc = plot_precision_recall_curve(
    y_test, 
    ensemble_pred, 
    'Hibrit Ensemble Model - Precision-Recall Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_pr_curve.png'
)

# LSTM model için Precision-Recall eğrisi
print("LSTM model için Precision-Recall eğrisi çiziliyor...")
lstm_pr_auc = plot_precision_recall_curve(
    lstm_y_test, 
    lstm_y_pred, 
    'LSTM Model - Precision-Recall Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/lstm_pr_curve.png'
)

# Eğitim geçmişi grafikleri
print("Eğitim geçmişi grafikleri çiziliyor...")
plot_training_history(
    bilstm_cnn_attention_history, 
    'BiLSTM+CNN+Attention Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/bilstm_cnn_attention_history.png'
)

plot_training_history(
    gru_history, 
    'GRU Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/gru_history.png'
)

plot_training_history(
    cnn_history, 
    'CNN Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/cnn_history.png'
)

# Ensemble model için sınıflandırma raporu
print("Ensemble model için sınıflandırma raporu hesaplanıyor...")
ensemble_report = classification_report(y_test, ensemble_pred_binary, output_dict=True)
ensemble_accuracy = (ensemble_cm[0, 0] + ensemble_cm[1, 1]) / ensemble_cm.sum()
ensemble_precision = ensemble_cm[1, 1] / (ensemble_cm[0, 1] + ensemble_cm[1, 1]) if (ensemble_cm[0, 1] + ensemble_cm[1, 1]) > 0 else 0
ensemble_recall = ensemble_cm[1, 1] / (ensemble_cm[1, 0] + ensemble_cm[1, 1]) if (ensemble_cm[1, 0] + ensemble_cm[1, 1]) > 0 else 0
ensemble_f1 = 2 * (ensemble_precision * ensemble_recall) / (ensemble_precision + ensemble_recall) if (ensemble_precision + ensemble_recall) > 0 else 0
ensemble_specificity = ensemble_cm[0, 0] / (ensemble_cm[0, 0] + ensemble_cm[0, 1]) if (ensemble_cm[0, 0] + ensemble_cm[0, 1]) > 0 else 0

# LSTM model için sınıflandırma raporu
print("LSTM model için sınıflandırma raporu hesaplanıyor...")
lstm_report = classification_report(lstm_y_test, lstm_y_pred_binary, output_dict=True)
lstm_accuracy = (lstm_cm[0, 0] + lstm_cm[1, 1]) / lstm_cm.sum()
lstm_precision = lstm_cm[1, 1] / (lstm_cm[0, 1] + lstm_cm[1, 1]) if (lstm_cm[0, 1] + lstm_cm[1, 1]) > 0 else 0
lstm_recall = lstm_cm[1, 1] / (lstm_cm[1, 0] + lstm_cm[1, 1]) if (lstm_cm[1, 0] + lstm_cm[1, 1]) > 0 else 0
lstm_f1 = 2 * (lstm_precision * lstm_recall) / (lstm_precision + lstm_recall) if (lstm_precision + lstm_recall) > 0 else 0
lstm_specificity = lstm_cm[0, 0] / (lstm_cm[0, 0] + lstm_cm[0, 1]) if (lstm_cm[0, 0] + lstm_cm[0, 1]) > 0 else 0

# Metrikleri karşılaştırma
print("Model metrikleri karşılaştırılıyor...")
metrics_dict = {
    'LSTM Model': {
        'Doğruluk': lstm_accuracy,
        'Kesinlik': lstm_precision,
        'Duyarlılık': lstm_recall,
        'F1 Skoru': lstm_f1,
        'Özgüllük': lstm_specificity,
        'ROC AUC': lstm_roc_auc
    },
    'Hibrit Ensemble Model': {
        'Doğruluk': ensemble_accuracy,
        'Kesinlik': ensemble_precision,
        'Duyarlılık': ensemble_recall,
        'F1 Skoru': ensemble_f1,
        'Özgüllük': ensemble_specificity,
        'ROC AUC': ensemble_roc_auc
    }
}

plot_model_comparison(
    metrics_dict, 
    'LSTM vs Hibrit Ensemble Model Performans Karşılaştırması',
    '/home/ubuntu/advanced_model/evaluation/model_comparison.png'
)

# Metrikleri CSV dosyasına kaydetme
print("Metrikler CSV dosyasına kaydediliyor...")
metrics_df = pd.DataFrame(metrics_dict)
metrics_df.to_csv('/home/ubuntu/advanced_model/evaluation/model_metrics_comparison.csv')

# Sonuçları yazdırma
print("\n===== LSTM Model Metrikleri =====")
print(f"Doğruluk (Accuracy): {lstm_accuracy:.4f}")
print(f"Kesinlik (Precision): {lstm_precision:.4f}")
print(f"Duyarlılık (Recall): {lstm_recall:.4f}")
print(f"F1 Skoru: {lstm_f1:.4f}")
print(f"Özgüllük (Specificity): {lstm_specificity:.4f}")
print(f"ROC AUC: {lstm_roc_auc:.4f}")
print(f"Karmaşıklık Matrisi:\n{lstm_cm}")

print("\n===== Hibrit Ensemble Model Metrikleri =====")
print(f"Doğruluk (Accuracy): {ensemble_accuracy:.4f}")
print(f"Kesinlik (Precision): {ensemble_precision:.4f}")
print(f"Duyarlılık (Recall): {ensemble_recall:.4f}")
print(f"F1 Skoru: {ensemble_f1:.4f}")
print(f"Özgüllük (Specificity): {ensemble_specificity:.4f}")
print(f"ROC AUC: {ensemble_roc_auc:.4f}")
print(f"Karmaşıklık Matrisi:\n{ensemble_cm}")

print("\n===== İyileştirme Oranları =====")
accuracy_improvement = ((ensemble_accuracy - lstm_accuracy) / lstm_accuracy) * 100
precision_improvement = ((ensemble_precision - lstm_precision) / lstm_precision) * 100
recall_improvement = ((ensemble_recall - lstm_recall) / lstm_recall) * 100
f1_improvement = ((ensemble_f1 - lstm_f1) / lstm_f1) * 100
specificity_improvement = ((ensemble_specificity - lstm_specificity) / lstm_specificity) * 100
roc_auc_improvement = ((ensemble_roc_auc - lstm_roc_auc) / lstm_roc_auc) * 100

print(f"Doğruluk İyileştirmesi: {accuracy_improvement:.2f}%")
print(f"Kesinlik İyileştirmesi: {precision_improvement:.2f}%")
print(f"Duyarlılık İyileştirmesi: {recall_improvement:.2f}%")
print(f"F1 Skoru İyileştirmesi: {f1_improvement:.2f}%")
print(f"Özgüllük İyileştirmesi: {specificity_improvement:.2f}%")
print(f"ROC AUC İyileştirmesi: {roc_auc_improvement:.2f}%")

# Sonuçları JSON dosyasına kaydetme
import json
results = {
    'lstm_model': {
        'accuracy': float(lstm_accuracy),
        'precision': float(lstm_precision),
        'recall': float(lstm_recall),
        'f1_score': float(lstm_f1),
        'specificity': float(lstm_specificity),
        'roc_auc': float(lstm_roc_auc),
        'confusion_matrix': lstm_cm.tolist()
    },
    'ensemble_model': {
        'accuracy': float(ensemble_accuracy),
        'precision': float(ensemble_precision),
        'recall': float(ensemble_recall),
        'f1_score': float(ensemble_f1),
        'specificity': float(ensemble_specificity),
        'roc_auc': float(ensemble_roc_auc),
        'confusion_matrix': ensemble_cm.tolist()
    },
    'improvement': {
        'accuracy': float(accuracy_improvement),
        'precision': float(precision_improvement),
        'recall': float(recall_improvement),
        'f1_score': float(f1_improvement),
        'specificity': float(specificity_improvement),
        'roc_auc': float(roc_auc_improvement)
    }
}

with open('/home/ubuntu/advanced_model/evaluation/model_evaluation_results.json', 'w') as f:
    json.dump(results, f, indent=4)

print("\nModel değerlendirmesi tamamlandı. Tüm metrikler ve grafikler kaydedildi.")
