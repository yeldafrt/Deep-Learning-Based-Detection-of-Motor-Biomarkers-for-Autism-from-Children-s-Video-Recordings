import tensorflow as tf
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Average, Lambda
import numpy as np

def create_ensemble_model():
    """
    3 bireysel modeli weighted average ile birleştiren ensemble model oluşturur
    """
    print("Ensemble model oluşturuluyor...")
    
    # Bireysel modelleri yükle
    print("Bireysel modeller yükleniyor...")
    bilstm_cnn_attention_model = load_model('/home/ubuntu/advanced_model/models/bilstm_cnn_attention_model.h5')
    gru_model = load_model('/home/ubuntu/advanced_model/models/gru_model.h5')
    cnn_model = load_model('/home/ubuntu/advanced_model/models/cnn_model.h5')
    
    # Input shape'i al
    input_shape = bilstm_cnn_attention_model.input_shape[1:]  # (100, 21)
    print(f"Input shape: {input_shape}")
    
    # Ensemble model input'u
    ensemble_input = Input(shape=input_shape, name='ensemble_input')
    
    # Her modelin çıktısını al (trainable=False yaparak ağırlıkları dondur)
    for layer in bilstm_cnn_attention_model.layers:
        layer.trainable = False
    for layer in gru_model.layers:
        layer.trainable = False
    for layer in cnn_model.layers:
        layer.trainable = False
    
    # Model çıktılarını al
    bilstm_output = bilstm_cnn_attention_model(ensemble_input)
    gru_output = gru_model(ensemble_input)
    cnn_output = cnn_model(ensemble_input)
    
    # Weighted average (0.5, 0.3, 0.2)
    def weighted_average(inputs):
        bilstm_pred, gru_pred, cnn_pred = inputs
        return 0.5 * bilstm_pred + 0.3 * gru_pred + 0.2 * cnn_pred
    
    ensemble_output = Lambda(weighted_average, name='weighted_ensemble')([bilstm_output, gru_output, cnn_output])
    
    # Ensemble model oluştur
    ensemble_model = Model(inputs=ensemble_input, outputs=ensemble_output, name='ensemble_model')
    
    # Model özetini göster
    print("\nEnsemble Model Özeti:")
    ensemble_model.summary()
    
    # Modeli kaydet
    print("\nEnsemble model kaydediliyor...")
    ensemble_model.save('/home/ubuntu/advanced_model/models/ensemble_model.h5')
    ensemble_model.save('/home/ubuntu/advanced_model/models/ensemble_model.keras')
    
    print("✅ Ensemble model başarıyla kaydedildi!")
    print("📁 Kaydedilen dosyalar:")
    print("   - ensemble_model.h5")
    print("   - ensemble_model.keras")
    
    return ensemble_model

def test_ensemble_model():
    """
    Ensemble modelini test et
    """
    print("\n🧪 Ensemble model test ediliyor...")
    
    # Test verilerini yükle
    X_test = np.load('/home/ubuntu/advanced_model/X_test_advanced.npy')
    y_test = np.load('/home/ubuntu/advanced_model/y_test_advanced.npy')
    
    print(f"Test veri şekli: {X_test.shape}")
    print(f"Test etiket şekli: {y_test.shape}")
    
    # Ensemble modelini yükle
    ensemble_model = load_model('/home/ubuntu/advanced_model/models/ensemble_model.h5')
    
    # Tahmin yap
    print("Tahminler yapılıyor...")
    ensemble_predictions = ensemble_model.predict(X_test)
    
    # Binary tahminler
    ensemble_binary = (ensemble_predictions > 0.5).astype(int)
    
    # Accuracy hesapla
    accuracy = np.mean(ensemble_binary.flatten() == y_test)
    print(f"🎯 Ensemble Model Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Sonuçları kaydet
    np.save('/home/ubuntu/advanced_model/results/ensemble_model_pred.npy', ensemble_predictions)
    np.save('/home/ubuntu/advanced_model/results/ensemble_model_binary.npy', ensemble_binary)
    
    print("✅ Test tamamlandı ve sonuçlar kaydedildi!")
    
    return accuracy

if __name__ == "__main__":
    # Ensemble model oluştur
    ensemble_model = create_ensemble_model()
    
    # Test et
    accuracy = test_ensemble_model()
    
    print(f"\n🎉 Ensemble model başarıyla oluşturuldu!")
    print(f"📊 Final Accuracy: {accuracy*100:.2f}%")

