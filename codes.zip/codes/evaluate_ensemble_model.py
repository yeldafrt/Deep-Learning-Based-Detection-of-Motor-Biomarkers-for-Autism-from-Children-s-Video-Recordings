import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc, precision_recall_curve
import pickle
import os

# Sonuçların kaydedileceği dizini oluştur
os.makedirs('/home/ubuntu/advanced_model/evaluation', exist_ok=True)

# Test sonuçlarını yükle
y_test = np.load('/home/ubuntu/advanced_model/results/y_test.npy')
ensemble_pred = np.load('/home/ubuntu/advanced_model/results/ensemble_pred.npy')
ensemble_pred_binary = np.load('/home/ubuntu/advanced_model/results/ensemble_pred_binary.npy')

# Eğitim geçmişini yükle
with open('/home/ubuntu/advanced_model/results/bilstm_cnn_attention_history.pkl', 'rb') as f:
    bilstm_cnn_attention_history = pickle.load(f)

with open('/home/ubuntu/advanced_model/results/gru_history.pkl', 'rb') as f:
    gru_history = pickle.load(f)

with open('/home/ubuntu/advanced_model/results/cnn_history.pkl', 'rb') as f:
    cnn_history = pickle.load(f)

# Karmaşıklık matrisi hesaplama
def plot_confusion_matrix(y_true, y_pred, title, filename):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)
    plt.title(title, fontsize=16)
    plt.ylabel('Gerçek Değer', fontsize=12)
    plt.xlabel('Tahmin Edilen Değer', fontsize=12)
    plt.xticks([0.5, 1.5], ['Sağlıklı (0)', 'Otizmli (1)'])
    plt.yticks([0.5, 1.5], ['Sağlıklı (0)', 'Otizmli (1)'])
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return cm

# ROC eğrisi çizme
def plot_roc_curve(y_true, y_pred_prob, title, filename):
    fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    
    plt.figure(figsize=(10, 8))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC eğrisi (AUC = {roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Yanlış Pozitif Oranı', fontsize=12)
    plt.ylabel('Doğru Pozitif Oranı', fontsize=12)
    plt.title(title, fontsize=16)
    plt.legend(loc="lower right", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return roc_auc

# Precision-Recall eğrisi çizme
def plot_precision_recall_curve(y_true, y_pred_prob, title, filename):
    precision, recall, _ = precision_recall_curve(y_true, y_pred_prob)
    pr_auc = auc(recall, precision)
    
    plt.figure(figsize=(10, 8))
    plt.plot(recall, precision, color='green', lw=2, label=f'PR eğrisi (AUC = {pr_auc:.3f})')
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title(title, fontsize=16)
    plt.legend(loc="lower left", fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    return pr_auc

# Eğitim geçmişi grafiği çizme
def plot_training_history(history, title, filename):
    plt.figure(figsize=(12, 10))
    
    plt.subplot(2, 2, 1)
    plt.plot(history['accuracy'], label='Eğitim')
    plt.plot(history['val_accuracy'], label='Validasyon')
    plt.title('Model Doğruluğu', fontsize=14)
    plt.ylabel('Doğruluk', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 2)
    plt.plot(history['loss'], label='Eğitim')
    plt.plot(history['val_loss'], label='Validasyon')
    plt.title('Model Kaybı', fontsize=14)
    plt.ylabel('Kayıp', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='upper right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 3)
    plt.plot(history['precision'], label='Eğitim')
    plt.plot(history['val_precision'], label='Validasyon')
    plt.title('Model Kesinliği (Precision)', fontsize=14)
    plt.ylabel('Kesinlik', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.subplot(2, 2, 4)
    plt.plot(history['recall'], label='Eğitim')
    plt.plot(history['val_recall'], label='Validasyon')
    plt.title('Model Duyarlılığı (Recall)', fontsize=14)
    plt.ylabel('Duyarlılık', fontsize=12)
    plt.xlabel('Epok', fontsize=12)
    plt.legend(loc='lower right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.suptitle(title, fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()

# Ensemble model için karmaşıklık matrisi
print("Ensemble model için karmaşıklık matrisi hesaplanıyor...")
ensemble_cm = plot_confusion_matrix(
    y_test, 
    ensemble_pred_binary, 
    'Hibrit Ensemble Model - Karmaşıklık Matrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_confusion_matrix.png'
)

# Ensemble model için ROC eğrisi
print("Ensemble model için ROC eğrisi çiziliyor...")
ensemble_roc_auc = plot_roc_curve(
    y_test, 
    ensemble_pred, 
    'Hibrit Ensemble Model - ROC Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_roc_curve.png'
)

# Ensemble model için Precision-Recall eğrisi
print("Ensemble model için Precision-Recall eğrisi çiziliyor...")
ensemble_pr_auc = plot_precision_recall_curve(
    y_test, 
    ensemble_pred, 
    'Hibrit Ensemble Model - Precision-Recall Eğrisi',
    '/home/ubuntu/advanced_model/evaluation/ensemble_pr_curve.png'
)

# Eğitim geçmişi grafikleri
print("Eğitim geçmişi grafikleri çiziliyor...")
plot_training_history(
    bilstm_cnn_attention_history, 
    'BiLSTM+CNN+Attention Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/bilstm_cnn_attention_history.png'
)

plot_training_history(
    gru_history, 
    'GRU Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/gru_history.png'
)

plot_training_history(
    cnn_history, 
    'CNN Model Eğitim Geçmişi',
    '/home/ubuntu/advanced_model/evaluation/cnn_history.png'
)

# Ensemble model için sınıflandırma raporu
print("Ensemble model için sınıflandırma raporu hesaplanıyor...")
ensemble_report = classification_report(y_test, ensemble_pred_binary, output_dict=True)
ensemble_accuracy = (ensemble_cm[0, 0] + ensemble_cm[1, 1]) / ensemble_cm.sum()
ensemble_precision = ensemble_cm[1, 1] / (ensemble_cm[0, 1] + ensemble_cm[1, 1]) if (ensemble_cm[0, 1] + ensemble_cm[1, 1]) > 0 else 0
ensemble_recall = ensemble_cm[1, 1] / (ensemble_cm[1, 0] + ensemble_cm[1, 1]) if (ensemble_cm[1, 0] + ensemble_cm[1, 1]) > 0 else 0
ensemble_f1 = 2 * (ensemble_precision * ensemble_recall) / (ensemble_precision + ensemble_recall) if (ensemble_precision + ensemble_recall) > 0 else 0
ensemble_specificity = ensemble_cm[0, 0] / (ensemble_cm[0, 0] + ensemble_cm[0, 1]) if (ensemble_cm[0, 0] + ensemble_cm[0, 1]) > 0 else 0

# Sonuçları yazdırma
print("\n===== Hibrit Ensemble Model Metrikleri =====")
print(f"Doğruluk (Accuracy): {ensemble_accuracy:.4f}")
print(f"Kesinlik (Precision): {ensemble_precision:.4f}")
print(f"Duyarlılık (Recall): {ensemble_recall:.4f}")
print(f"F1 Skoru: {ensemble_f1:.4f}")
print(f"Özgüllük (Specificity): {ensemble_specificity:.4f}")
print(f"ROC AUC: {ensemble_roc_auc:.4f}")
print(f"Karmaşıklık Matrisi:\n{ensemble_cm}")

# Sonuçları JSON dosyasına kaydetme
import json
results = {
    'ensemble_model': {
        'accuracy': float(ensemble_accuracy),
        'precision': float(ensemble_precision),
        'recall': float(ensemble_recall),
        'f1_score': float(ensemble_f1),
        'specificity': float(ensemble_specificity),
        'roc_auc': float(ensemble_roc_auc),
        'confusion_matrix': ensemble_cm.tolist()
    }
}

with open('/home/ubuntu/advanced_model/evaluation/model_evaluation_results.json', 'w') as f:
    json.dump(results, f, indent=4)

print("\nModel değerlendirmesi tamamlandı. Tüm metrikler ve grafikler kaydedildi.")
