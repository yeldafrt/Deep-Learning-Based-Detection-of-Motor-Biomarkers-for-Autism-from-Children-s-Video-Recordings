import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from scipy.fft import fft
from scipy.signal import find_peaks
import os

# Sonuçların kaydedileceği dizini oluştur
os.makedirs('/home/ubuntu/advanced_model', exist_ok=True)

# Birleştirilmiş veri setini yükleme
combined_df = pd.read_csv('/home/ubuntu/advanced_model/combined_pose_features.csv')

print("Veri seti boyutu:", combined_df.shape)
print("Sütunlar:", combined_df.columns.tolist())
print("Otizm etiketli veri sayısı:", len(combined_df[combined_df['label'] == 1]))
print("Sağlıklı etiketli veri sayısı:", len(combined_df[combined_df['label'] == 0]))

# Özellik sütunlarını belirleme
feature_columns = ['left_shoulder_move', 'right_shoulder_move', 'left_elbow_move', 
                  'right_elbow_move', 'left_wrist_move', 'right_wrist_move', 'nose_move']

# Video bazında gruplandırma
video_groups = combined_df.groupby('video')
video_list = combined_df['video'].unique()
print(f"Toplam benzersiz video sayısı: {len(video_list)}")

# LSTM için dizi uzunluğunu belirleme
# Her video için frame sayısını kontrol edelim
frame_counts = combined_df.groupby('video').size()
print("Frame sayıları istatistikleri:")
print(f"Minimum frame sayısı: {frame_counts.min()}")
print(f"Maksimum frame sayısı: {frame_counts.max()}")
print(f"Ortalama frame sayısı: {frame_counts.mean():.2f}")
print(f"Medyan frame sayısı: {frame_counts.median()}")

# Sabit bir dizi uzunluğu belirleyelim (örneğin medyan değere yakın bir sayı)
SEQUENCE_LENGTH = 100  # Bu değer veri setine göre ayarlanabilir

# Gelişmiş özellik mühendisliği fonksiyonları
def calculate_movement_statistics(sequence):
    """Hareket istatistiklerini hesaplar"""
    stats = {}
    stats['mean'] = np.mean(sequence)
    stats['std'] = np.std(sequence)
    stats['max'] = np.max(sequence)
    stats['min'] = np.min(sequence)
    stats['range'] = stats['max'] - stats['min']
    stats['median'] = np.median(sequence)
    stats['iqr'] = np.percentile(sequence, 75) - np.percentile(sequence, 25)
    stats['skewness'] = 0 if stats['std'] == 0 else np.mean(((sequence - stats['mean']) / stats['std']) ** 3)
    stats['kurtosis'] = 0 if stats['std'] == 0 else np.mean(((sequence - stats['mean']) / stats['std']) ** 4) - 3
    return stats

def calculate_frequency_features(sequence, sampling_rate=30):
    """Frekans domeni özelliklerini hesaplar"""
    # FFT uygula
    fft_result = fft(sequence)
    # Genlik spektrumu
    magnitude = np.abs(fft_result)
    # Frekans bileşenleri
    freqs = np.fft.fftfreq(len(sequence), 1/sampling_rate)
    
    # Sadece pozitif frekansları al
    positive_freq_idx = freqs > 0
    freqs = freqs[positive_freq_idx]
    magnitude = magnitude[positive_freq_idx]
    
    # Dominant frekanslar
    if len(magnitude) > 0:
        peaks, _ = find_peaks(magnitude, height=0.1*np.max(magnitude))
        dominant_freqs = freqs[peaks] if len(peaks) > 0 else [0]
        dominant_magnitudes = magnitude[peaks] if len(peaks) > 0 else [0]
    else:
        dominant_freqs = [0]
        dominant_magnitudes = [0]
    
    # Frekans özellikleri
    freq_features = {
        'dominant_freq': dominant_freqs[0] if len(dominant_freqs) > 0 else 0,
        'dominant_magnitude': dominant_magnitudes[0] if len(dominant_magnitudes) > 0 else 0,
        'mean_magnitude': np.mean(magnitude),
        'std_magnitude': np.std(magnitude),
        'spectral_centroid': np.sum(freqs * magnitude) / np.sum(magnitude) if np.sum(magnitude) > 0 else 0,
        'spectral_bandwidth': np.sqrt(np.sum(((freqs - np.mean(freqs)) ** 2) * magnitude) / np.sum(magnitude)) if np.sum(magnitude) > 0 else 0
    }
    return freq_features

def detect_repetitive_movements(sequence, threshold=0.5):
    """Tekrarlayan hareket örüntülerini tespit eder"""
    # Hareket değişimlerini hesapla
    diffs = np.diff(sequence)
    # Yön değişimlerini bul (pozitiften negatife veya tersi)
    direction_changes = np.where(np.diff(np.signbit(diffs)))[0]
    
    # Tekrarlayan hareket skoru
    if len(direction_changes) > 1:
        # Yön değişimleri arasındaki mesafeleri hesapla
        intervals = np.diff(direction_changes)
        # Mesafelerin standart sapması / ortalaması (düşük değer daha düzenli tekrarı gösterir)
        regularity = np.std(intervals) / np.mean(intervals) if np.mean(intervals) > 0 else 0
        # Tekrar sayısı
        repetition_count = len(direction_changes)
        # Tekrar skoru (daha düzenli ve daha fazla tekrar = daha yüksek skor)
        repetition_score = repetition_count * (1 - min(regularity, 1))
    else:
        repetition_score = 0
    
    return {
        'repetition_score': repetition_score,
        'direction_changes': len(direction_changes),
        'is_repetitive': repetition_score > threshold
    }

def calculate_coordination_features(left_seq, right_seq):
    """Sol ve sağ uzuv hareketleri arasındaki koordinasyon özelliklerini hesaplar"""
    # Korelasyon
    correlation = np.corrcoef(left_seq, right_seq)[0, 1] if len(left_seq) > 1 and len(right_seq) > 1 else 0
    # Faz farkı
    phase_diff = np.mean(np.abs(np.diff(left_seq) - np.diff(right_seq)))
    # Senkronizasyon
    sync_score = 1 - min(1, abs(np.std(left_seq) - np.std(right_seq)) / max(np.std(left_seq), np.std(right_seq))) if max(np.std(left_seq), np.std(right_seq)) > 0 else 0
    
    return {
        'correlation': correlation,
        'phase_diff': phase_diff,
        'sync_score': sync_score
    }

def extract_advanced_features(df, video_name, seq_length, feature_cols):
    """Bir video için gelişmiş özellikler çıkarır"""
    video_data = df[df['video'] == video_name]
    
    # Video çok kısaysa, bu videoyu atlayalım
    if len(video_data) < seq_length:
        return None, None
    
    # Etiket (tüm video için aynı)
    label = video_data['label'].iloc[0]
    
    # Özellik dizileri oluşturma
    sequences = []
    total_frames = len(video_data)
    
    # Örtüşen diziler oluşturalım (veri artırma için)
    stride = max(1, seq_length // 4)  # Diziler arasında %75 örtüşme
    
    for start in range(0, total_frames - seq_length + 1, stride):
        end = start + seq_length
        seq_data = video_data.iloc[start:end]
        
        # Temel özellikler
        base_features = seq_data[feature_cols].values
        
        # Gelişmiş özellikler için boş dizi
        advanced_features = np.zeros((seq_length, len(feature_cols) * 3))  # 3 kat daha fazla özellik
        
        # Her özellik için gelişmiş özellikler hesapla
        for i, col in enumerate(feature_cols):
            col_data = seq_data[col].values
            
            # Temel özellikleri kopyala
            advanced_features[:, i] = col_data
            
            # Frekans özellikleri
            freq_features = calculate_frequency_features(col_data)
            # Tekrarlayan hareket özellikleri
            repetitive_features = detect_repetitive_movements(col_data)
            
            # Hareketli pencere ile yerel özellikler (her kare için)
            window_size = 10  # 10 karelik pencere
            for j in range(seq_length):
                window_start = max(0, j - window_size // 2)
                window_end = min(seq_length, j + window_size // 2)
                window_data = col_data[window_start:window_end]
                
                # Yerel istatistikler
                stats = calculate_movement_statistics(window_data)
                
                # Gelişmiş özellikleri ekle
                advanced_features[j, i + len(feature_cols)] = stats['std']  # Standart sapma
                advanced_features[j, i + 2*len(feature_cols)] = repetitive_features['repetition_score']  # Tekrar skoru
        
        # Koordinasyon özellikleri
        if 'left_shoulder_move' in feature_cols and 'right_shoulder_move' in feature_cols:
            left_idx = feature_cols.index('left_shoulder_move')
            right_idx = feature_cols.index('right_shoulder_move')
            coord_features = calculate_coordination_features(
                seq_data['left_shoulder_move'].values, 
                seq_data['right_shoulder_move'].values
            )
            # Koordinasyon özelliklerini ekle (tüm kareler için aynı değer)
            for j in range(seq_length):
                # Burada ek özellikler eklenebilir
                pass
        
        sequences.append(advanced_features)
    
    return sequences, label

# Tüm videolar için gelişmiş özellikler çıkarma
X_advanced = []
y_advanced = []

print("Gelişmiş özellik çıkarma başlatılıyor...")
for i, video in enumerate(video_list):
    sequences, label = extract_advanced_features(combined_df, video, SEQUENCE_LENGTH, feature_columns)
    if sequences is not None:
        X_advanced.extend(sequences)
        y_advanced.extend([label] * len(sequences))
    
    if (i+1) % 10 == 0:
        print(f"{i+1}/{len(video_list)} video işlendi...")

# Numpy dizilerine dönüştürme
X_advanced = np.array(X_advanced)
y_advanced = np.array(y_advanced)

print(f"Oluşturulan gelişmiş dizi sayısı: {len(X_advanced)}")
print(f"X_advanced şekli: {X_advanced.shape}")
print(f"y_advanced şekli: {y_advanced.shape}")
print(f"Sınıf dağılımı: {np.bincount(y_advanced)}")

# SMOTE ile veri dengeleme
print("SMOTE ile veri dengeleme başlatılıyor...")
# Veriyi 2D formata düzenle (SMOTE için gerekli)
n_samples, seq_length, n_features = X_advanced.shape
X_reshaped = X_advanced.reshape(n_samples, seq_length * n_features)

# SMOTE uygula
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_reshaped, y_advanced)

# Veriyi orijinal 3D formata geri dönüştür
X_balanced = X_resampled.reshape(-1, seq_length, n_features)
y_balanced = y_resampled

print(f"Dengeleme sonrası dizi sayısı: {len(X_balanced)}")
print(f"X_balanced şekli: {X_balanced.shape}")
print(f"y_balanced şekli: {y_balanced.shape}")
print(f"Dengelenmiş sınıf dağılımı: {np.bincount(y_balanced)}")

# Eğitim ve test setlerine ayırma
X_train, X_test, y_train, y_test = train_test_split(X_balanced, y_balanced, test_size=0.2, random_state=42, stratify=y_balanced)

print(f"Eğitim seti boyutu: {X_train.shape}")
print(f"Test seti boyutu: {X_test.shape}")
print(f"Eğitim seti sınıf dağılımı: {np.bincount(y_train)}")
print(f"Test seti sınıf dağılımı: {np.bincount(y_test)}")

# Veriyi kaydetme
np.save('/home/ubuntu/advanced_model/X_train_advanced.npy', X_train)
np.save('/home/ubuntu/advanced_model/X_test_advanced.npy', X_test)
np.save('/home/ubuntu/advanced_model/y_train_advanced.npy', y_train)
np.save('/home/ubuntu/advanced_model/y_test_advanced.npy', y_test)

print("Veri dengeleme ve gelişmiş özellik mühendisliği tamamlandı.")
