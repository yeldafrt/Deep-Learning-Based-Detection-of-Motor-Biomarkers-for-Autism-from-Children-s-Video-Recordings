import os
import cv2
import mediapipe as mp
import pandas as pd
from math import sqrt

# === Ayarlar ===
klasor_yolu = r"C:\Users\Hp\Desktop\otizm\otizm_hazırlık\veriseti\saglikli"
csv_cikis_yolu = "40_kare_bazli_pose_ozellikleri_saglikli_fsm.csv"
hedef_fps = 10  # FPS normalizasyon değeri

# === MediaPipe Pose başlat ===
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.3)

# === Kullanılacak landmark'lar ===
landmark_indices = {
    'left_shoulder': mp_pose.PoseLandmark.LEFT_SHOULDER.value,
    'right_shoulder': mp_pose.PoseLandmark.RIGHT_SHOULDER.value,
    'left_elbow': mp_pose.PoseLandmark.LEFT_ELBOW.value,
    'right_elbow': mp_pose.PoseLandmark.RIGHT_ELBOW.value,
    'left_wrist': mp_pose.PoseLandmark.LEFT_WRIST.value,
    'right_wrist': mp_pose.PoseLandmark.RIGHT_WRIST.value,
    'nose': mp_pose.PoseLandmark.NOSE.value
}

tum_veri = []

# === Video döngüsü ===
for video_adi in os.listdir(klasor_yolu):
    if video_adi.endswith(".mp4"):
        video_yolu = os.path.join(klasor_yolu, video_adi)
        cap = cv2.VideoCapture(video_yolu)

        orijinal_fps = cap.get(cv2.CAP_PROP_FPS)
        step = int(round(orijinal_fps / hedef_fps)) if orijinal_fps > hedef_fps else 1

        onceki_koordinatlar = {k: (None, None) for k in landmark_indices}
        frame_index = 0
        video_frame_index = 0

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # FSM: sadece belirli kareleri analiz et
            if video_frame_index % step != 0:
                video_frame_index += 1
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = pose.process(rgb)

            hareketler = {}
            if results.pose_landmarks:
                for isim, idx in landmark_indices.items():
                    lm = results.pose_landmarks.landmark[idx]
                    x, y = lm.x, lm.y
                    onceki_x, onceki_y = onceki_koordinatlar[isim]
                    if onceki_x is not None:
                        dx = x - onceki_x
                        dy = y - onceki_y
                        hareket = sqrt(dx**2 + dy**2)
                    else:
                        hareket = 0.0
                    hareketler[isim + '_move'] = hareket
                    onceki_koordinatlar[isim] = (x, y)
            else:
                for isim in landmark_indices:
                    hareketler[isim + '_move'] = 0.0

            tum_veri.append({
                "video": video_adi,
                "frame": frame_index,
                **hareketler
            })

            frame_index += 1
            video_frame_index += 1

        cap.release()

# === CSV çıktısı ===
df = pd.DataFrame(tum_veri)
df.to_csv(csv_cikis_yolu, index=False, encoding='utf-8')
print(f"✅ FSM ile öznitelikler çıkarıldı: {csv_cikis_yolu}")
