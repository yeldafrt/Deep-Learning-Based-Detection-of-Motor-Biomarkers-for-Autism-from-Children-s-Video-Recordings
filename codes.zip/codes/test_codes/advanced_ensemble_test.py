#!/usr/bin/env python3
"""
Advanced Ensemble Test
Advanced feature engineering ile çıkarılan 21 özellik ile ensemble model test yapar
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
import os

def load_ensemble_model():
    """Ensemble modelini yükle"""
    print("🤖 Ensemble model yükleniyor...")
    
    try:
        # Bireysel modelleri yükle (ensemble model sorunlu)
        bilstm_path = '/home/ubuntu/advanced_model/models/bilstm_cnn_attention_model.h5'
        gru_path = '/home/ubuntu/advanced_model/models/gru_model.h5'
        cnn_path = '/home/ubuntu/advanced_model/models/cnn_model.h5'
        
        bilstm_model = load_model(bilstm_path)
        gru_model = load_model(gru_path)
        cnn_model = load_model(cnn_path)
        
        print("✅ Tüm bireysel modeller başarıyla yüklendi!")
        return bilstm_model, gru_model, cnn_model
        
    except Exception as e:
        print(f"❌ Model yükleme hatası: {e}")
        return None, None, None

def load_advanced_test_data():
    """Advanced test verilerini yükle"""
    print("📊 Advanced test verileri yükleniyor...")
    
    try:
        # Advanced feature engineering sonuçlarını yükle
        X_test = np.load('/home/ubuntu/external_test_features_advanced.npy')
        y_test = np.load('/home/ubuntu/external_test_labels_advanced.npy')
        
        print(f"✅ Advanced test verileri yüklendi:")
        print(f"   X_test shape: {X_test.shape}")
        print(f"   y_test shape: {y_test.shape}")
        print(f"   Autism samples: {np.sum(y_test)}")
        print(f"   Healthy samples: {len(y_test) - np.sum(y_test)}")
        print(f"   Feature dimensions: {X_test.shape[2]} (advanced features)")
        
        return X_test, y_test
        
    except Exception as e:
        print(f"❌ Veri yükleme hatası: {e}")
        return None, None

def advanced_ensemble_prediction(models, X_test):
    """Advanced features ile ensemble tahmin"""
    print("🎯 Advanced ensemble tahminler yapılıyor...")
    
    try:
        bilstm_model, gru_model, cnn_model = models
        
        print("   BiLSTM+CNN+Attention tahminleri...")
        bilstm_pred = bilstm_model.predict(X_test, verbose=0)
        
        print("   GRU tahminleri...")
        gru_pred = gru_model.predict(X_test, verbose=0)
        
        print("   CNN tahminleri...")
        cnn_pred = cnn_model.predict(X_test, verbose=0)
        
        # Weighted ensemble (0.5, 0.3, 0.2)
        print("   Ensemble hesaplaması (50% + 30% + 20%)...")
        ensemble_pred = 0.5 * bilstm_pred + 0.3 * gru_pred + 0.2 * cnn_pred
        
        # Binary tahminler (0.5 threshold)
        ensemble_binary = (ensemble_pred > 0.5).astype(int)
        
        return {
            'bilstm': bilstm_pred,
            'gru': gru_pred,
            'cnn': cnn_pred,
            'ensemble': ensemble_pred,
            'ensemble_binary': ensemble_binary
        }
        
    except Exception as e:
        print(f"❌ Tahmin hatası: {e}")
        return None

def calculate_advanced_metrics(predictions, y_test):
    """Advanced classification metriklerini hesapla"""
    print("📊 Advanced classification metrikleri hesaplanıyor...")
    
    results = {}
    
    for model_name, pred in predictions.items():
        if model_name == 'ensemble_binary':
            continue
            
        # Binary tahminler
        if model_name == 'ensemble':
            binary_pred = predictions['ensemble_binary']
        else:
            binary_pred = (pred > 0.5).astype(int)
        
        # Confusion Matrix
        cm = confusion_matrix(y_test, binary_pred.flatten())
        tn, fp, fn, tp = cm.ravel()
        
        # Temel metrikler
        accuracy = (tp + tn) / (tp + tn + fp + fn)
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0  # Autism detection rate
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0  # Healthy detection rate
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = sensitivity
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        # Balanced accuracy
        balanced_accuracy = (sensitivity + specificity) / 2
        
        # ROC AUC
        try:
            fpr, tpr, _ = roc_curve(y_test, pred.flatten())
            roc_auc = auc(fpr, tpr)
        except:
            roc_auc = 0.5
        
        # Confidence statistics
        confidence_scores = pred.flatten()
        mean_confidence = np.mean(confidence_scores)
        std_confidence = np.std(confidence_scores)
        
        results[model_name] = {
            'confusion_matrix': cm,
            'accuracy': accuracy,
            'balanced_accuracy': balanced_accuracy,
            'sensitivity': sensitivity,
            'specificity': specificity,
            'precision': precision,
            'recall': recall,
            'f1_score': f1_score,
            'roc_auc': roc_auc,
            'mean_confidence': mean_confidence,
            'std_confidence': std_confidence,
            'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn
        }
        
        print(f"   {model_name.upper()}:")
        print(f"      Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        print(f"      Balanced Accuracy: {balanced_accuracy:.4f} ({balanced_accuracy*100:.2f}%)")
        print(f"      Sensitivity: {sensitivity:.4f} ({sensitivity*100:.2f}%)")
        print(f"      Specificity: {specificity:.4f} ({specificity*100:.2f}%)")
        print(f"      F1-Score: {f1_score:.4f} ({f1_score*100:.2f}%)")
    
    return results

def create_advanced_results_visualization(results):
    """Advanced test sonuçlarını görselleştir - başlıksız, İngilizce, 300 DPI"""
    print("📈 Advanced test sonuçları görselleştiriliyor...")
    
    # Model isimleri ve metrikler
    models = ['BiLSTM+CNN+Attention', 'GRU', 'CNN', 'Ensemble']
    model_keys = ['bilstm', 'gru', 'cnn', 'ensemble']
    
    # Metrikler
    accuracies = [results[key]['accuracy'] * 100 for key in model_keys]
    balanced_accuracies = [results[key]['balanced_accuracy'] * 100 for key in model_keys]
    sensitivities = [results[key]['sensitivity'] * 100 for key in model_keys]
    specificities = [results[key]['specificity'] * 100 for key in model_keys]
    
    # Grafik oluştur
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12), dpi=300)
    
    x = np.arange(len(models))
    width = 0.6
    
    # 1. Accuracy
    bars1 = ax1.bar(x, accuracies, width, color='#2E86AB', alpha=0.8)
    for bar, value in zip(bars1, accuracies):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax1.set_ylabel('Accuracy (%)', fontsize=12, fontweight='bold')
    ax1.set_xlabel('Models', fontsize=12, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels(models, fontsize=10, rotation=45, ha='right')
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.set_ylim(0, 105)
    
    # 2. Balanced Accuracy
    bars2 = ax2.bar(x, balanced_accuracies, width, color='#A23B72', alpha=0.8)
    for bar, value in zip(bars2, balanced_accuracies):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax2.set_ylabel('Balanced Accuracy (%)', fontsize=12, fontweight='bold')
    ax2.set_xlabel('Models', fontsize=12, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels(models, fontsize=10, rotation=45, ha='right')
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_ylim(0, 105)
    
    # 3. Sensitivity (Autism Detection)
    bars3 = ax3.bar(x, sensitivities, width, color='#F18F01', alpha=0.8)
    for bar, value in zip(bars3, sensitivities):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax3.set_ylabel('Sensitivity - Autism Detection (%)', fontsize=12, fontweight='bold')
    ax3.set_xlabel('Models', fontsize=12, fontweight='bold')
    ax3.set_xticks(x)
    ax3.set_xticklabels(models, fontsize=10, rotation=45, ha='right')
    ax3.grid(True, alpha=0.3, axis='y')
    ax3.set_ylim(0, 105)
    
    # 4. Specificity (Healthy Detection)
    bars4 = ax4.bar(x, specificities, width, color='#C73E1D', alpha=0.8)
    for bar, value in zip(bars4, specificities):
        height = bar.get_height()
        ax4.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax4.set_ylabel('Specificity - Healthy Detection (%)', fontsize=12, fontweight='bold')
    ax4.set_xlabel('Models', fontsize=12, fontweight='bold')
    ax4.set_xticks(x)
    ax4.set_xticklabels(models, fontsize=10, rotation=45, ha='right')
    ax4.grid(True, alpha=0.3, axis='y')
    ax4.set_ylim(0, 105)
    
    # Layout ayarları
    plt.tight_layout()
    
    # Kaydet
    output_path = '/home/ubuntu/advanced_external_test_results.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Grafik kaydedildi: {output_path}")
    return output_path

def save_advanced_detailed_results(results, predictions, y_test):
    """Detaylı advanced test sonuçlarını kaydet"""
    print("💾 Detaylı advanced test sonuçları kaydediliyor...")
    
    with open('/home/ubuntu/advanced_external_test_detailed.txt', 'w') as f:
        f.write("ADVANCED EXTERNAL TEST RESULTS (21 FEATURES)\n")
        f.write("="*60 + "\n\n")
        
        f.write("ADVANCED FEATURE ENGINEERING:\n")
        f.write("- Real 21 features (same as training set)\n")
        f.write("- Movement statistics (mean, std, max, min, range, median, IQR)\n")
        f.write("- Frequency domain features (FFT, dominant frequency, spectral)\n")
        f.write("- Repetitive movement detection (repetition score, direction changes)\n")
        f.write("- Coordination features (left-right synchronization)\n\n")
        
        f.write("TEST DATASET:\n")
        f.write(f"Total samples: {len(y_test)}\n")
        f.write(f"Autism samples: {np.sum(y_test)} ({np.sum(y_test)/len(y_test)*100:.1f}%)\n")
        f.write(f"Healthy samples: {len(y_test) - np.sum(y_test)} ({(len(y_test) - np.sum(y_test))/len(y_test)*100:.1f}%)\n\n")
        
        f.write("ENSEMBLE MODEL PERFORMANCE:\n")
        f.write("-" * 40 + "\n")
        ensemble_results = results['ensemble']
        f.write(f"Accuracy:           {ensemble_results['accuracy']:.4f} ({ensemble_results['accuracy']*100:.2f}%)\n")
        f.write(f"Balanced Accuracy:  {ensemble_results['balanced_accuracy']:.4f} ({ensemble_results['balanced_accuracy']*100:.2f}%)\n")
        f.write(f"Sensitivity (TPR):  {ensemble_results['sensitivity']:.4f} ({ensemble_results['sensitivity']*100:.2f}%)\n")
        f.write(f"Specificity (TNR):  {ensemble_results['specificity']:.4f} ({ensemble_results['specificity']*100:.2f}%)\n")
        f.write(f"Precision (PPV):    {ensemble_results['precision']:.4f} ({ensemble_results['precision']*100:.2f}%)\n")
        f.write(f"F1-Score:           {ensemble_results['f1_score']:.4f} ({ensemble_results['f1_score']*100:.2f}%)\n")
        f.write(f"ROC AUC:            {ensemble_results['roc_auc']:.4f}\n\n")
        
        f.write("CONFUSION MATRIX (ENSEMBLE):\n")
        f.write("                Predicted\n")
        f.write("              Healthy  Autism\n")
        f.write(f"True Healthy     {ensemble_results['tn']:2d}      {ensemble_results['fp']:2d}\n")
        f.write(f"     Autism      {ensemble_results['fn']:2d}      {ensemble_results['tp']:2d}\n\n")
        
        f.write("INDIVIDUAL MODEL COMPARISON:\n")
        f.write("-" * 50 + "\n")
        f.write("Model                | Accuracy | Balanced Acc | Sensitivity | Specificity\n")
        f.write("-" * 70 + "\n")
        for model_name, metrics in results.items():
            f.write(f"{model_name:18s} | {metrics['accuracy']*100:7.2f}% | {metrics['balanced_accuracy']*100:10.2f}% | {metrics['sensitivity']*100:9.2f}% | {metrics['specificity']*100:9.2f}%\n")
        
        f.write(f"\nIMPROVEMENT ANALYSIS:\n")
        f.write("-" * 30 + "\n")
        f.write("Compared to previous simple feature extraction:\n")
        f.write("- Previous External Test: 47.50% accuracy\n")
        f.write("- Previous Balanced Accuracy: 50.00%\n")
        f.write("- Previous Healthy Detection: 0.00%\n")
        f.write(f"- Current External Test: {ensemble_results['accuracy']*100:.2f}% accuracy\n")
        f.write(f"- Current Balanced Accuracy: {ensemble_results['balanced_accuracy']*100:.2f}%\n")
        f.write(f"- Current Healthy Detection: {ensemble_results['specificity']*100:.2f}%\n")
    
    # Tahminleri kaydet
    np.save('/home/ubuntu/advanced_external_test_predictions.npy', predictions['ensemble'])
    np.save('/home/ubuntu/advanced_external_test_binary.npy', predictions['ensemble_binary'])
    
    print("✅ Detaylı advanced test sonuçları kaydedildi!")

def main():
    """Ana fonksiyon"""
    print("🚀 ADVANCED EXTERNAL TEST WITH ENSEMBLE MODEL")
    print("="*70)
    
    # Ensemble modelini yükle
    models = load_ensemble_model()
    if models[0] is None:
        return
    
    # Advanced test verilerini yükle
    X_test, y_test = load_advanced_test_data()
    if X_test is None:
        return
    
    # Advanced ensemble tahminleri yap
    predictions = advanced_ensemble_prediction(models, X_test)
    if predictions is None:
        return
    
    # Advanced metriklerini hesapla
    results = calculate_advanced_metrics(predictions, y_test)
    
    # Sonuçları görselleştir
    graph_path = create_advanced_results_visualization(results)
    
    # Detaylı sonuçları kaydet
    save_advanced_detailed_results(results, predictions, y_test)
    
    # Özet yazdır
    print("\n🎉 ADVANCED EXTERNAL TEST TAMAMLANDI!")
    print("="*70)
    print(f"📊 ENSEMBLE MODEL ADVANCED PERFORMANCE:")
    ensemble_results = results['ensemble']
    print(f"   Accuracy: {ensemble_results['accuracy']:.4f} ({ensemble_results['accuracy']*100:.2f}%)")
    print(f"   Balanced Accuracy: {ensemble_results['balanced_accuracy']:.4f} ({ensemble_results['balanced_accuracy']*100:.2f}%)")
    print(f"   Autism Detection: {ensemble_results['sensitivity']:.4f} ({ensemble_results['sensitivity']*100:.2f}%)")
    print(f"   Healthy Detection: {ensemble_results['specificity']:.4f} ({ensemble_results['specificity']*100:.2f}%)")
    print(f"   F1-Score: {ensemble_results['f1_score']:.4f} ({ensemble_results['f1_score']*100:.2f}%)")
    print(f"📈 Grafik: {graph_path}")
    print(f"📄 Detaylı sonuçlar: /home/ubuntu/advanced_external_test_detailed.txt")

if __name__ == "__main__":
    main()

