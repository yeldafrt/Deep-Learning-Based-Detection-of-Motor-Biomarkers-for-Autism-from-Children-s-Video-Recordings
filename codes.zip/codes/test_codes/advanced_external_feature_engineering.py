#!/usr/bin/env python3
"""
Advanced External Feature Engineering
External test videoları için gelişmiş özellik mühendisliği yapar
Orijinal feature_engineering.py kodunu kullanır
"""

import os
import cv2
import mediapipe as mp
import pandas as pd
import numpy as np
from math import sqrt
from scipy.fft import fft
from scipy.signal import find_peaks
from sklearn.preprocessing import StandardScaler

# === Ayarlar ===
autism_klasor = "/home/ubuntu/external_test_dataset/autism"
healthy_klasor = "/home/ubuntu/external_test_dataset/healthy"
hedef_fps = 10  # FPS normalizasyon değeri
SEQUENCE_LENGTH = 100  # Her video için hedef frame sayısı

# === MediaPipe Pose başlat ===
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.3)

# === Kullanılacak landmark'lar ===
landmark_indices = {
    'left_shoulder': mp_pose.PoseLandmark.LEFT_SHOULDER.value,
    'right_shoulder': mp_pose.PoseLandmark.RIGHT_SHOULDER.value,
    'left_elbow': mp_pose.PoseLandmark.LEFT_ELBOW.value,
    'right_elbow': mp_pose.PoseLandmark.RIGHT_ELBOW.value,
    'left_wrist': mp_pose.PoseLandmark.LEFT_WRIST.value,
    'right_wrist': mp_pose.PoseLandmark.RIGHT_WRIST.value,
    'nose': mp_pose.PoseLandmark.NOSE.value
}

feature_columns = ['left_shoulder_move', 'right_shoulder_move', 'left_elbow_move', 
                  'right_elbow_move', 'left_wrist_move', 'right_wrist_move', 'nose_move']

def calculate_movement_statistics(sequence):
    """Hareket istatistiklerini hesaplar"""
    stats = {}
    stats['mean'] = np.mean(sequence)
    stats['std'] = np.std(sequence)
    stats['max'] = np.max(sequence)
    stats['min'] = np.min(sequence)
    stats['range'] = stats['max'] - stats['min']
    stats['median'] = np.median(sequence)
    stats['iqr'] = np.percentile(sequence, 75) - np.percentile(sequence, 25)
    stats['skewness'] = 0 if stats['std'] == 0 else np.mean(((sequence - stats['mean']) / stats['std']) ** 3)
    stats['kurtosis'] = 0 if stats['std'] == 0 else np.mean(((sequence - stats['mean']) / stats['std']) ** 4) - 3
    return stats

def calculate_frequency_features(sequence, sampling_rate=10):
    """Frekans domeni özelliklerini hesaplar"""
    # FFT uygula
    fft_result = fft(sequence)
    # Genlik spektrumu
    magnitude = np.abs(fft_result)
    # Frekans bileşenleri
    freqs = np.fft.fftfreq(len(sequence), 1/sampling_rate)
    
    # Sadece pozitif frekansları al
    positive_freq_idx = freqs > 0
    freqs = freqs[positive_freq_idx]
    magnitude = magnitude[positive_freq_idx]
    
    # Dominant frekanslar
    if len(magnitude) > 0:
        peaks, _ = find_peaks(magnitude, height=0.1*np.max(magnitude))
        dominant_freqs = freqs[peaks] if len(peaks) > 0 else [0]
        dominant_magnitudes = magnitude[peaks] if len(peaks) > 0 else [0]
    else:
        dominant_freqs = [0]
        dominant_magnitudes = [0]
    
    # Frekans özellikleri
    freq_features = {
        'dominant_freq': dominant_freqs[0] if len(dominant_freqs) > 0 else 0,
        'dominant_magnitude': dominant_magnitudes[0] if len(dominant_magnitudes) > 0 else 0,
        'mean_magnitude': np.mean(magnitude),
        'std_magnitude': np.std(magnitude),
        'spectral_centroid': np.sum(freqs * magnitude) / np.sum(magnitude) if np.sum(magnitude) > 0 else 0,
        'spectral_bandwidth': np.sqrt(np.sum(((freqs - np.mean(freqs)) ** 2) * magnitude) / np.sum(magnitude)) if np.sum(magnitude) > 0 else 0
    }
    return freq_features

def detect_repetitive_movements(sequence, threshold=0.5):
    """Tekrarlayan hareket örüntülerini tespit eder"""
    # Hareket değişimlerini hesapla
    diffs = np.diff(sequence)
    # Yön değişimlerini bul (pozitiften negatife veya tersi)
    direction_changes = np.where(np.diff(np.signbit(diffs)))[0]
    
    # Tekrarlayan hareket skoru
    if len(direction_changes) > 1:
        # Yön değişimleri arasındaki mesafeleri hesapla
        intervals = np.diff(direction_changes)
        # Mesafelerin standart sapması / ortalaması (düşük değer daha düzenli tekrarı gösterir)
        regularity = np.std(intervals) / np.mean(intervals) if np.mean(intervals) > 0 else 0
        # Tekrar sayısı
        repetition_count = len(direction_changes)
        # Tekrar skoru (daha düzenli ve daha fazla tekrar = daha yüksek skor)
        repetition_score = repetition_count * (1 - min(regularity, 1))
    else:
        repetition_score = 0
    
    return {
        'repetition_score': repetition_score,
        'direction_changes': len(direction_changes),
        'is_repetitive': repetition_score > threshold
    }

def calculate_coordination_features(left_seq, right_seq):
    """Sol ve sağ uzuv hareketleri arasındaki koordinasyon özelliklerini hesaplar"""
    # Korelasyon
    correlation = np.corrcoef(left_seq, right_seq)[0, 1] if len(left_seq) > 1 and len(right_seq) > 1 else 0
    # Faz farkı
    phase_diff = np.mean(np.abs(np.diff(left_seq) - np.diff(right_seq)))
    # Senkronizasyon
    sync_score = 1 - min(1, abs(np.std(left_seq) - np.std(right_seq)) / max(np.std(left_seq), np.std(right_seq))) if max(np.std(left_seq), np.std(right_seq)) > 0 else 0
    
    return {
        'correlation': correlation,
        'phase_diff': phase_diff,
        'sync_score': sync_score
    }

def process_video_advanced(video_path, label):
    """Tek bir videoyu gelişmiş özellik çıkarımı ile işle"""
    print(f"   İşleniyor: {os.path.basename(video_path)}")
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"   ❌ Video açılamadı: {video_path}")
        return None
    
    orijinal_fps = cap.get(cv2.CAP_PROP_FPS)
    step = int(round(orijinal_fps / hedef_fps)) if orijinal_fps > hedef_fps else 1
    
    onceki_koordinatlar = {k: (None, None) for k in landmark_indices}
    frame_data = []
    video_frame_index = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # FSM: sadece belirli kareleri analiz et
        if video_frame_index % step != 0:
            video_frame_index += 1
            continue
        
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(rgb)
        
        hareketler = []
        if results.pose_landmarks:
            for isim, idx in landmark_indices.items():
                lm = results.pose_landmarks.landmark[idx]
                x, y = lm.x, lm.y
                onceki_x, onceki_y = onceki_koordinatlar[isim]
                if onceki_x is not None:
                    dx = x - onceki_x
                    dy = y - onceki_y
                    hareket = sqrt(dx**2 + dy**2)
                else:
                    hareket = 0.0
                hareketler.append(hareket)
                onceki_koordinatlar[isim] = (x, y)
        else:
            # Landmark bulunamazsa sıfır hareket
            hareketler = [0.0] * len(landmark_indices)
        
        frame_data.append(hareketler)
        video_frame_index += 1
    
    cap.release()
    
    if len(frame_data) == 0:
        print(f"   ❌ Hiç frame işlenemedi: {video_path}")
        return None
    
    # Frame sayısını normalize et (100 frame'e)
    frame_data = np.array(frame_data)
    
    if len(frame_data) >= SEQUENCE_LENGTH:
        # Fazla frame varsa eşit aralıklarla seç
        indices = np.linspace(0, len(frame_data)-1, SEQUENCE_LENGTH, dtype=int)
        normalized_data = frame_data[indices]
    else:
        # Az frame varsa tekrarla
        repeat_factor = SEQUENCE_LENGTH // len(frame_data)
        remainder = SEQUENCE_LENGTH % len(frame_data)
        
        repeated_data = np.tile(frame_data, (repeat_factor, 1))
        if remainder > 0:
            additional_data = frame_data[:remainder]
            normalized_data = np.vstack([repeated_data, additional_data])
        else:
            normalized_data = repeated_data
    
    # DataFrame oluştur (gelişmiş özellik çıkarımı için)
    df_data = []
    for i, row in enumerate(normalized_data):
        frame_dict = {'frame': i, 'video': os.path.basename(video_path), 'label': label}
        for j, col in enumerate(feature_columns):
            frame_dict[col] = row[j]
        df_data.append(frame_dict)
    
    video_df = pd.DataFrame(df_data)
    
    # Gelişmiş özellik çıkarımı
    advanced_features = extract_advanced_features_single_video(video_df, SEQUENCE_LENGTH, feature_columns)
    
    print(f"   ✅ {len(frame_data)} frame → {len(normalized_data)} frame → {advanced_features.shape} advanced features")
    return advanced_features, label

def extract_advanced_features_single_video(df, seq_length, feature_cols):
    """Bir video için gelişmiş özellikler çıkarır"""
    # Gelişmiş özellikler için boş dizi (21 özellik)
    advanced_features = np.zeros((seq_length, len(feature_cols) * 3))  # 3 kat daha fazla özellik
    
    # Her özellik için gelişmiş özellikler hesapla
    for i, col in enumerate(feature_cols):
        col_data = df[col].values
        
        # Temel özellikleri kopyala
        advanced_features[:, i] = col_data
        
        # Frekans özellikleri
        freq_features = calculate_frequency_features(col_data)
        # Tekrarlayan hareket özellikleri
        repetitive_features = detect_repetitive_movements(col_data)
        
        # Hareketli pencere ile yerel özellikler (her kare için)
        window_size = 10  # 10 karelik pencere
        for j in range(seq_length):
            window_start = max(0, j - window_size // 2)
            window_end = min(seq_length, j + window_size // 2)
            window_data = col_data[window_start:window_end]
            
            # Yerel istatistikler
            stats = calculate_movement_statistics(window_data)
            
            # Gelişmiş özellikleri ekle
            advanced_features[j, i + len(feature_cols)] = stats['std']  # Standart sapma
            advanced_features[j, i + 2*len(feature_cols)] = repetitive_features['repetition_score']  # Tekrar skoru
    
    return advanced_features

def main():
    """Ana fonksiyon"""
    print("🚀 ADVANCED EXTERNAL FEATURE ENGINEERING")
    print("="*60)
    
    all_features = []
    all_labels = []
    
    # Autism videoları
    print("📹 Autism videoları işleniyor...")
    autism_files = [f for f in os.listdir(autism_klasor) if f.endswith(('.mp4', '.mkv', '.webm', '.avi'))]
    autism_files.sort()
    
    for i, video_file in enumerate(autism_files, 1):
        print(f"   {i}/{len(autism_files)}: {video_file}")
        video_path = os.path.join(autism_klasor, video_file)
        result = process_video_advanced(video_path, 1)  # 1 = Autism
        
        if result is not None:
            features, label = result
            all_features.append(features)
            all_labels.append(label)
    
    # Healthy videoları
    print("📹 Healthy videoları işleniyor...")
    healthy_files = [f for f in os.listdir(healthy_klasor) if f.endswith(('.mp4', '.mkv', '.webm', '.avi'))]
    healthy_files.sort()
    
    for i, video_file in enumerate(healthy_files, 1):
        print(f"   {i}/{len(healthy_files)}: {video_file}")
        video_path = os.path.join(healthy_klasor, video_file)
        result = process_video_advanced(video_path, 0)  # 0 = Healthy
        
        if result is not None:
            features, label = result
            all_features.append(features)
            all_labels.append(label)
    
    if len(all_features) == 0:
        print("❌ Hiç video işlenemedi!")
        return
    
    # Numpy array'e çevir
    X_test = np.array(all_features)
    y_test = np.array(all_labels)
    
    print(f"\n📊 ADVANCED EXTERNAL TEST VERİ ÖZETİ:")
    print(f"   X_test shape: {X_test.shape}")
    print(f"   y_test shape: {y_test.shape}")
    print(f"   Autism samples: {np.sum(y_test)}")
    print(f"   Healthy samples: {len(y_test) - np.sum(y_test)}")
    print(f"   Total videos: {len(y_test)}")
    print(f"   Feature dimensions: {X_test.shape[2]} (21 advanced features)")
    
    # Veriyi kaydet
    print("\n💾 Advanced veriler kaydediliyor...")
    np.save('/home/ubuntu/external_test_features_advanced.npy', X_test)
    np.save('/home/ubuntu/external_test_labels_advanced.npy', y_test)
    
    print("✅ Advanced external test verileri başarıyla kaydedildi!")
    print("📁 Kaydedilen dosyalar:")
    print("   - external_test_features_advanced.npy")
    print("   - external_test_labels_advanced.npy")
    
    # Özet istatistikler
    print(f"\n📈 ADVANCED ÖZELLİK İSTATİSTİKLERİ:")
    feature_names = []
    for name in ['left_shoulder', 'right_shoulder', 'left_elbow', 'right_elbow', 
                'left_wrist', 'right_wrist', 'nose']:
        feature_names.extend([f'{name}_move', f'{name}_std', f'{name}_repetition'])
    
    for i, name in enumerate(feature_names):
        feature_data = X_test[:, :, i].flatten()
        print(f"   {name}: mean={np.mean(feature_data):.6f}, std={np.std(feature_data):.6f}")

if __name__ == "__main__":
    main()

