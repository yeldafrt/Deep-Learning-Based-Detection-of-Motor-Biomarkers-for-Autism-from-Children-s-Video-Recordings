#!/usr/bin/env python3
"""
Autism-Only External Test
Sadece autism videolarıyla ensemble model performansını test eder
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
import os

def load_ensemble_model():
    """Ensemble modelini yükle"""
    print("🤖 Ensemble model yükleniyor...")
    
    try:
        # Ensemble model dosya yolu
        ensemble_path = '/home/ubuntu/advanced_model/models/ensemble_model.h5'
        
        # Custom objects tanımla (Lambda layer için)
        def weighted_average(inputs):
            bilstm_pred, gru_pred, cnn_pred = inputs
            return 0.5 * bilstm_pred + 0.3 * gru_pred + 0.2 * cnn_pred
        
        custom_objects = {'weighted_average': weighted_average}
        
        # Ensemble modelini yükle
        ensemble_model = load_model(ensemble_path, custom_objects=custom_objects)
        
        print("✅ Ensemble model başarıyla yüklendi!")
        return ensemble_model
        
    except Exception as e:
        print(f"❌ Ensemble model yükleme hatası: {e}")
        print("🔄 Bireysel modelleri yüklemeye çalışıyorum...")
        return load_individual_models_fallback()

def load_individual_models_fallback():
    """Bireysel modelleri yükle (fallback)"""
    print("🤖 Bireysel modeller yükleniyor...")
    
    try:
        # Model dosya yolları
        bilstm_path = '/home/ubuntu/advanced_model/models/bilstm_cnn_attention_model.h5'
        gru_path = '/home/ubuntu/advanced_model/models/gru_model.h5'
        cnn_path = '/home/ubuntu/advanced_model/models/cnn_model.h5'
        
        # Modelleri yükle
        bilstm_model = load_model(bilstm_path)
        gru_model = load_model(gru_path)
        cnn_model = load_model(cnn_path)
        
        print("✅ Tüm bireysel modeller başarıyla yüklendi!")
        return bilstm_model, gru_model, cnn_model
        
    except Exception as e:
        print(f"❌ Model yükleme hatası: {e}")
        return None, None, None

def load_autism_only_data():
    """Sadece autism verilerini yükle"""
    print("📊 Autism-only test verileri yükleniyor...")
    
    try:
        # 21 özellikli external test verilerini yükle
        X_test_path = '/home/ubuntu/external_test_features_21.npy'
        y_test_path = '/home/ubuntu/external_test_labels_21.npy'
        
        X_test = np.load(X_test_path)
        y_test = np.load(y_test_path)
        
        # Sadece autism örneklerini al (label=1)
        autism_indices = np.where(y_test == 1)[0]
        X_autism = X_test[autism_indices]
        y_autism = y_test[autism_indices]
        
        print(f"✅ Autism-only veriler yüklendi:")
        print(f"   X_autism shape: {X_autism.shape}")
        print(f"   y_autism shape: {y_autism.shape}")
        print(f"   Autism samples: {len(y_autism)}")
        print(f"   All labels should be 1: {np.unique(y_autism)}")
        
        return X_autism, y_autism
        
    except Exception as e:
        print(f"❌ Veri yükleme hatası: {e}")
        return None, None

def autism_prediction(model, X_autism):
    """Autism videolarıyla tahmin"""
    print("🎯 Autism videolarıyla tahminler yapılıyor...")
    
    try:
        if isinstance(model, tuple):
            # Bireysel modeller kullanılıyor (fallback)
            bilstm_model, gru_model, cnn_model = model
            
            print("   BiLSTM+CNN+Attention tahminleri...")
            bilstm_pred = bilstm_model.predict(X_autism, verbose=0)
            
            print("   GRU tahminleri...")
            gru_pred = gru_model.predict(X_autism, verbose=0)
            
            print("   CNN tahminleri...")
            cnn_pred = cnn_model.predict(X_autism, verbose=0)
            
            # Weighted ensemble (0.5, 0.3, 0.2)
            print("   Ensemble hesaplaması (50% + 30% + 20%)...")
            ensemble_pred = 0.5 * bilstm_pred + 0.3 * gru_pred + 0.2 * cnn_pred
            
            return {
                'bilstm': bilstm_pred,
                'gru': gru_pred,
                'cnn': cnn_pred,
                'ensemble': ensemble_pred,
                'ensemble_binary': (ensemble_pred > 0.5).astype(int)
            }
        else:
            # Ensemble model kullanılıyor
            print("   Ensemble model ile tahmin...")
            ensemble_pred = model.predict(X_autism, verbose=0)
            
            return {
                'ensemble': ensemble_pred,
                'ensemble_binary': (ensemble_pred > 0.5).astype(int)
            }
        
    except Exception as e:
        print(f"❌ Tahmin hatası: {e}")
        return None

def calculate_autism_metrics(predictions, y_autism):
    """Autism detection performans metriklerini hesapla"""
    print("📊 Autism detection metrikleri hesaplanıyor...")
    
    results = {}
    
    for model_name, pred in predictions.items():
        if model_name == 'ensemble_binary':
            continue
            
        # Binary tahminler
        if model_name == 'ensemble':
            binary_pred = predictions['ensemble_binary']
        else:
            binary_pred = (pred > 0.5).astype(int)
        
        # Autism detection accuracy (tüm örnekler autism olmalı)
        correct_autism_detection = np.sum(binary_pred.flatten() == 1)
        total_autism_samples = len(y_autism)
        autism_detection_rate = correct_autism_detection / total_autism_samples
        
        # Confidence statistics
        confidence_scores = pred.flatten()
        mean_confidence = np.mean(confidence_scores)
        std_confidence = np.std(confidence_scores)
        min_confidence = np.min(confidence_scores)
        max_confidence = np.max(confidence_scores)
        
        results[model_name] = {
            'autism_detection_rate': autism_detection_rate,
            'correct_detections': correct_autism_detection,
            'total_samples': total_autism_samples,
            'mean_confidence': mean_confidence,
            'std_confidence': std_confidence,
            'min_confidence': min_confidence,
            'max_confidence': max_confidence
        }
        
        print(f"   {model_name.upper()}: Autism Detection Rate={autism_detection_rate:.4f} ({autism_detection_rate*100:.2f}%)")
        print(f"      Confidence: mean={mean_confidence:.3f}, std={std_confidence:.3f}")
    
    return results

def create_autism_results_visualization(results):
    """Autism detection sonuçlarını görselleştir - başlıksız, İngilizce, 300 DPI"""
    print("📈 Autism detection sonuçları görselleştiriliyor...")
    
    # Model isimleri ve metrikler
    if 'bilstm' in results:
        models = ['BiLSTM+CNN+Attention', 'GRU', 'CNN', 'Ensemble']
        model_keys = ['bilstm', 'gru', 'cnn', 'ensemble']
    else:
        models = ['Ensemble']
        model_keys = ['ensemble']
    
    detection_rates = [results[key]['autism_detection_rate'] * 100 for key in model_keys]
    mean_confidences = [results[key]['mean_confidence'] * 100 for key in model_keys]
    
    # Grafik oluştur
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8), dpi=300)
    
    # Sol grafik: Autism Detection Rate
    x = np.arange(len(models))
    bars1 = ax1.bar(x, detection_rates, color='#2E86AB', alpha=0.8, width=0.6)
    
    # Değerleri bar üzerine yaz
    for bar, value in zip(bars1, detection_rates):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=12, fontweight='bold')
    
    ax1.set_ylabel('Autism Detection Rate (%)', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Models', fontsize=14, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels(models, fontsize=12)
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.set_ylim(0, 105)
    ax1.set_yticks(range(0, 101, 10))
    
    # Sağ grafik: Mean Confidence
    bars2 = ax2.bar(x, mean_confidences, color='#A23B72', alpha=0.8, width=0.6)
    
    # Değerleri bar üzerine yaz
    for bar, value in zip(bars2, mean_confidences):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=12, fontweight='bold')
    
    ax2.set_ylabel('Mean Confidence (%)', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Models', fontsize=14, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels(models, fontsize=12)
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_ylim(0, 105)
    ax2.set_yticks(range(0, 101, 10))
    
    # Layout ayarları
    plt.tight_layout()
    
    # Kaydet
    output_path = '/home/ubuntu/autism_only_test_results.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Grafik kaydedildi: {output_path}")
    return output_path

def save_autism_detailed_results(results, predictions, y_autism):
    """Detaylı autism detection sonuçlarını kaydet"""
    print("💾 Detaylı autism detection sonuçları kaydediliyor...")
    
    # Sonuçları text dosyasına kaydet
    with open('/home/ubuntu/autism_only_detailed_results.txt', 'w') as f:
        f.write("AUTISM-ONLY EXTERNAL TEST RESULTS\n")
        f.write("="*50 + "\n\n")
        
        f.write("TEST DATASET:\n")
        f.write(f"Total autism samples: {len(y_autism)}\n")
        f.write(f"Expected detection rate: 100% (all samples are autism)\n\n")
        
        f.write("AUTISM DETECTION PERFORMANCE:\n")
        f.write("-" * 40 + "\n")
        
        for model_name, metrics in results.items():
            f.write(f"\n{model_name.upper()}:\n")
            f.write(f"  Autism Detection Rate: {metrics['autism_detection_rate']:.4f} ({metrics['autism_detection_rate']*100:.2f}%)\n")
            f.write(f"  Correct Detections: {metrics['correct_detections']}/{metrics['total_samples']}\n")
            f.write(f"  Mean Confidence: {metrics['mean_confidence']:.4f} ({metrics['mean_confidence']*100:.2f}%)\n")
            f.write(f"  Confidence Std: {metrics['std_confidence']:.4f}\n")
            f.write(f"  Confidence Range: [{metrics['min_confidence']:.4f}, {metrics['max_confidence']:.4f}]\n")
    
    # Tahminleri numpy dosyalarına kaydet
    np.save('/home/ubuntu/autism_only_ensemble_predictions.npy', predictions['ensemble'])
    np.save('/home/ubuntu/autism_only_ensemble_binary.npy', predictions['ensemble_binary'])
    
    print("✅ Detaylı autism detection sonuçları kaydedildi!")

def main():
    """Ana fonksiyon"""
    print("🚀 AUTISM-ONLY EXTERNAL TEST")
    print("="*50)
    
    # Ensemble modelini yükle
    model = load_ensemble_model()
    if model is None:
        return
    
    # Sadece autism verilerini yükle
    X_autism, y_autism = load_autism_only_data()
    if X_autism is None:
        return
    
    # Autism tahminleri yap
    predictions = autism_prediction(model, X_autism)
    if predictions is None:
        return
    
    # Autism detection metriklerini hesapla
    results = calculate_autism_metrics(predictions, y_autism)
    
    # Sonuçları görselleştir
    graph_path = create_autism_results_visualization(results)
    
    # Detaylı sonuçları kaydet
    save_autism_detailed_results(results, predictions, y_autism)
    
    # Özet yazdır
    print("\n🎉 AUTISM-ONLY TEST TAMAMLANDI!")
    print("="*50)
    print(f"📊 ENSEMBLE MODEL AUTISM DETECTION:")
    ensemble_rate = results['ensemble']['autism_detection_rate']
    ensemble_conf = results['ensemble']['mean_confidence']
    print(f"   Detection Rate: {ensemble_rate:.4f} ({ensemble_rate*100:.2f}%)")
    print(f"   Mean Confidence: {ensemble_conf:.4f} ({ensemble_conf*100:.2f}%)")
    print(f"📈 Grafik: {graph_path}")
    print(f"📄 Detaylı sonuçlar: /home/ubuntu/autism_only_detailed_results.txt")

if __name__ == "__main__":
    main()

