#!/usr/bin/env python3
"""
Balanced External Test with Optimal Threshold
Hem autism hem healthy videolarıyla optimal threshold (0.10) ile test yapar
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
import os

def load_ensemble_model():
    """Ensemble modelini yükle"""
    print("🤖 Ensemble model yükleniyor...")
    
    try:
        # Bireysel modelleri yükle (ensemble model sorunlu)
        bilstm_path = '/home/ubuntu/advanced_model/models/bilstm_cnn_attention_model.h5'
        gru_path = '/home/ubuntu/advanced_model/models/gru_model.h5'
        cnn_path = '/home/ubuntu/advanced_model/models/cnn_model.h5'
        
        bilstm_model = load_model(bilstm_path)
        gru_model = load_model(gru_path)
        cnn_model = load_model(cnn_path)
        
        print("✅ Tüm bireysel modeller başarıyla yüklendi!")
        return bilstm_model, gru_model, cnn_model
        
    except Exception as e:
        print(f"❌ Model yükleme hatası: {e}")
        return None, None, None

def load_balanced_test_data():
    """Balanced test verilerini yükle (39 autism + 1 healthy)"""
    print("📊 Balanced test verileri yükleniyor...")
    
    try:
        # 21 özellikli external test verilerini yükle
        X_test = np.load('/home/ubuntu/external_test_features_21.npy')
        y_test = np.load('/home/ubuntu/external_test_labels_21.npy')
        
        print(f"✅ Balanced test verileri yüklendi:")
        print(f"   X_test shape: {X_test.shape}")
        print(f"   y_test shape: {y_test.shape}")
        print(f"   Autism samples: {np.sum(y_test)}")
        print(f"   Healthy samples: {len(y_test) - np.sum(y_test)}")
        print(f"   Class distribution: {np.bincount(y_test)}")
        
        return X_test, y_test
        
    except Exception as e:
        print(f"❌ Veri yükleme hatası: {e}")
        return None, None

def balanced_prediction_with_optimal_threshold(models, X_test, optimal_threshold=0.10):
    """Optimal threshold ile balanced tahmin"""
    print(f"🎯 Optimal threshold ({optimal_threshold}) ile tahminler yapılıyor...")
    
    try:
        bilstm_model, gru_model, cnn_model = models
        
        print("   BiLSTM+CNN+Attention tahminleri...")
        bilstm_pred = bilstm_model.predict(X_test, verbose=0)
        
        print("   GRU tahminleri...")
        gru_pred = gru_model.predict(X_test, verbose=0)
        
        print("   CNN tahminleri...")
        cnn_pred = cnn_model.predict(X_test, verbose=0)
        
        # Weighted ensemble (0.5, 0.3, 0.2)
        print("   Ensemble hesaplaması (50% + 30% + 20%)...")
        ensemble_pred = 0.5 * bilstm_pred + 0.3 * gru_pred + 0.2 * cnn_pred
        
        # Optimal threshold ile binary tahminler
        print(f"   Optimal threshold ({optimal_threshold}) uygulanıyor...")
        ensemble_binary = (ensemble_pred > optimal_threshold).astype(int)
        
        return {
            'bilstm': bilstm_pred,
            'gru': gru_pred,
            'cnn': cnn_pred,
            'ensemble': ensemble_pred,
            'ensemble_binary': ensemble_binary
        }
        
    except Exception as e:
        print(f"❌ Tahmin hatası: {e}")
        return None

def calculate_balanced_metrics(predictions, y_test):
    """Balanced classification metriklerini hesapla"""
    print("📊 Balanced classification metrikleri hesaplanıyor...")
    
    ensemble_pred = predictions['ensemble']
    ensemble_binary = predictions['ensemble_binary']
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, ensemble_binary.flatten())
    tn, fp, fn, tp = cm.ravel()
    
    # Temel metrikler
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0  # Autism detection rate
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0  # Healthy detection rate
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = sensitivity
    f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    # Balanced accuracy
    balanced_accuracy = (sensitivity + specificity) / 2
    
    # ROC AUC
    try:
        fpr, tpr, _ = roc_curve(y_test, ensemble_pred.flatten())
        roc_auc = auc(fpr, tpr)
    except:
        roc_auc = 0.5
    
    results = {
        'confusion_matrix': cm,
        'accuracy': accuracy,
        'balanced_accuracy': balanced_accuracy,
        'sensitivity': sensitivity,  # True Positive Rate (Autism detection)
        'specificity': specificity,  # True Negative Rate (Healthy detection)
        'precision': precision,
        'recall': recall,
        'f1_score': f1_score,
        'roc_auc': roc_auc,
        'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn
    }
    
    print(f"✅ Balanced metrics hesaplandı:")
    print(f"   Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"   Balanced Accuracy: {balanced_accuracy:.4f} ({balanced_accuracy*100:.2f}%)")
    print(f"   Sensitivity (Autism Detection): {sensitivity:.4f} ({sensitivity*100:.2f}%)")
    print(f"   Specificity (Healthy Detection): {specificity:.4f} ({specificity*100:.2f}%)")
    print(f"   Precision: {precision:.4f} ({precision*100:.2f}%)")
    print(f"   F1-Score: {f1_score:.4f} ({f1_score*100:.2f}%)")
    print(f"   ROC AUC: {roc_auc:.4f}")
    
    return results

def create_balanced_results_visualization(results):
    """Balanced test sonuçlarını görselleştir"""
    print("📈 Balanced test sonuçları görselleştiriliyor...")
    
    # Metrikler
    metrics = ['Accuracy', 'Balanced Accuracy', 'Sensitivity\n(Autism Detection)', 
               'Specificity\n(Healthy Detection)', 'Precision', 'F1-Score']
    values = [results['accuracy']*100, results['balanced_accuracy']*100, 
              results['sensitivity']*100, results['specificity']*100,
              results['precision']*100, results['f1_score']*100]
    
    # Grafik oluştur
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8), dpi=300)
    
    # Sol grafik: Performance Metrics
    x = np.arange(len(metrics))
    bars = ax1.bar(x, values, color=['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#4CAF50', '#9C27B0'], alpha=0.8)
    
    # Değerleri bar üzerine yaz
    for bar, value in zip(bars, values):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 1,
               f'{value:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    ax1.set_ylabel('Performance (%)', fontsize=14, fontweight='bold')
    ax1.set_xlabel('Metrics', fontsize=14, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels(metrics, fontsize=10, rotation=45, ha='right')
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.set_ylim(0, 105)
    ax1.set_yticks(range(0, 101, 10))
    
    # Sağ grafik: Confusion Matrix
    cm = results['confusion_matrix']
    im = ax2.imshow(cm, interpolation='nearest', cmap='Blues')
    
    # Confusion matrix labels
    classes = ['Healthy', 'Autism']
    tick_marks = np.arange(len(classes))
    ax2.set_xticks(tick_marks)
    ax2.set_yticks(tick_marks)
    ax2.set_xticklabels(classes, fontsize=12)
    ax2.set_yticklabels(classes, fontsize=12)
    ax2.set_xlabel('Predicted Label', fontsize=14, fontweight='bold')
    ax2.set_ylabel('True Label', fontsize=14, fontweight='bold')
    
    # Confusion matrix values
    thresh = cm.max() / 2.
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax2.text(j, i, format(cm[i, j], 'd'),
                    ha="center", va="center", fontsize=16, fontweight='bold',
                    color="white" if cm[i, j] > thresh else "black")
    
    # Layout ayarları
    plt.tight_layout()
    
    # Kaydet
    output_path = '/home/ubuntu/balanced_external_test_results.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Grafik kaydedildi: {output_path}")
    return output_path

def save_balanced_detailed_results(results, predictions, y_test):
    """Detaylı balanced test sonuçlarını kaydet"""
    print("💾 Detaylı balanced test sonuçları kaydediliyor...")
    
    with open('/home/ubuntu/balanced_external_test_detailed.txt', 'w') as f:
        f.write("BALANCED EXTERNAL TEST RESULTS (OPTIMAL THRESHOLD = 0.10)\n")
        f.write("="*70 + "\n\n")
        
        f.write("TEST DATASET:\n")
        f.write(f"Total samples: {len(y_test)}\n")
        f.write(f"Autism samples: {np.sum(y_test)} ({np.sum(y_test)/len(y_test)*100:.1f}%)\n")
        f.write(f"Healthy samples: {len(y_test) - np.sum(y_test)} ({(len(y_test) - np.sum(y_test))/len(y_test)*100:.1f}%)\n\n")
        
        f.write("CONFUSION MATRIX:\n")
        f.write("                Predicted\n")
        f.write("              Healthy  Autism\n")
        f.write(f"True Healthy     {results['tn']:2d}      {results['fp']:2d}\n")
        f.write(f"     Autism      {results['fn']:2d}      {results['tp']:2d}\n\n")
        
        f.write("PERFORMANCE METRICS:\n")
        f.write("-" * 40 + "\n")
        f.write(f"Accuracy:           {results['accuracy']:.4f} ({results['accuracy']*100:.2f}%)\n")
        f.write(f"Balanced Accuracy:  {results['balanced_accuracy']:.4f} ({results['balanced_accuracy']*100:.2f}%)\n")
        f.write(f"Sensitivity (TPR):  {results['sensitivity']:.4f} ({results['sensitivity']*100:.2f}%)\n")
        f.write(f"Specificity (TNR):  {results['specificity']:.4f} ({results['specificity']*100:.2f}%)\n")
        f.write(f"Precision (PPV):    {results['precision']:.4f} ({results['precision']*100:.2f}%)\n")
        f.write(f"Recall:             {results['recall']:.4f} ({results['recall']*100:.2f}%)\n")
        f.write(f"F1-Score:           {results['f1_score']:.4f} ({results['f1_score']*100:.2f}%)\n")
        f.write(f"ROC AUC:            {results['roc_auc']:.4f}\n\n")
        
        f.write("INTERPRETATION:\n")
        f.write("-" * 20 + "\n")
        f.write(f"• Autism Detection Rate: {results['sensitivity']*100:.1f}% ({results['tp']}/{results['tp']+results['fn']} autism videos correctly identified)\n")
        f.write(f"• Healthy Detection Rate: {results['specificity']*100:.1f}% ({results['tn']}/{results['tn']+results['fp']} healthy videos correctly identified)\n")
        f.write(f"• False Positive Rate: {(1-results['specificity'])*100:.1f}% (healthy videos misclassified as autism)\n")
        f.write(f"• False Negative Rate: {(1-results['sensitivity'])*100:.1f}% (autism videos misclassified as healthy)\n")
    
    # Tahminleri kaydet
    np.save('/home/ubuntu/balanced_external_test_predictions.npy', predictions['ensemble'])
    np.save('/home/ubuntu/balanced_external_test_binary.npy', predictions['ensemble_binary'])
    
    print("✅ Detaylı balanced test sonuçları kaydedildi!")

def main():
    """Ana fonksiyon"""
    print("🚀 BALANCED EXTERNAL TEST WITH OPTIMAL THRESHOLD")
    print("="*60)
    
    # Ensemble modelini yükle
    models = load_ensemble_model()
    if models[0] is None:
        return
    
    # Balanced test verilerini yükle
    X_test, y_test = load_balanced_test_data()
    if X_test is None:
        return
    
    # Optimal threshold ile tahminleri yap
    predictions = balanced_prediction_with_optimal_threshold(models, X_test, optimal_threshold=0.10)
    if predictions is None:
        return
    
    # Balanced metriklerini hesapla
    results = calculate_balanced_metrics(predictions, y_test)
    
    # Sonuçları görselleştir
    graph_path = create_balanced_results_visualization(results)
    
    # Detaylı sonuçları kaydet
    save_balanced_detailed_results(results, predictions, y_test)
    
    # Özet yazdır
    print("\n🎉 BALANCED EXTERNAL TEST TAMAMLANDI!")
    print("="*60)
    print(f"📊 OPTIMAL THRESHOLD (0.10) SONUÇLARI:")
    print(f"   Balanced Accuracy: {results['balanced_accuracy']:.4f} ({results['balanced_accuracy']*100:.2f}%)")
    print(f"   Autism Detection: {results['sensitivity']:.4f} ({results['sensitivity']*100:.2f}%)")
    print(f"   Healthy Detection: {results['specificity']:.4f} ({results['specificity']*100:.2f}%)")
    print(f"   Overall Accuracy: {results['accuracy']:.4f} ({results['accuracy']*100:.2f}%)")
    print(f"📈 Grafik: {graph_path}")
    print(f"📄 Detaylı sonuçlar: /home/ubuntu/balanced_external_test_detailed.txt")

if __name__ == "__main__":
    main()

