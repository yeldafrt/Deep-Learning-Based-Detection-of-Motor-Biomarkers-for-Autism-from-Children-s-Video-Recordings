#!/usr/bin/env python3
"""
Feature Expansion: 7 features to 21 features
Mevcut 7 hareket özelliğini velocity, acceleration, jerk ekleyerek 21'e çıkarır
"""

import numpy as np
import pandas as pd

def calculate_velocity(movement_data):
    """Hareket verilerinden velocity hesapla"""
    velocity = np.zeros_like(movement_data)
    velocity[1:] = movement_data[1:] - movement_data[:-1]
    return velocity

def calculate_acceleration(velocity_data):
    """Velocity verilerinden acceleration hesapla"""
    acceleration = np.zeros_like(velocity_data)
    acceleration[1:] = velocity_data[1:] - velocity_data[:-1]
    return acceleration

def calculate_jerk(acceleration_data):
    """Acceleration verilerinden jerk hesapla"""
    jerk = np.zeros_like(acceleration_data)
    jerk[1:] = acceleration_data[1:] - acceleration_data[:-1]
    return jerk

def expand_features_to_21(X_data):
    """
    7 özelliği 21 özelliğe genişlet
    Input: (n_samples, 100, 7) - 7 hareket özelliği
    Output: (n_samples, 100, 21) - 21 özellik (7×3)
    """
    print("🔧 7 özellik → 21 özellik genişletme başlıyor...")
    
    n_samples, n_frames, n_features = X_data.shape
    print(f"   Input shape: {X_data.shape}")
    
    # 21 özellik için yeni array
    X_expanded = np.zeros((n_samples, n_frames, 21))
    
    feature_names = ['left_shoulder', 'right_shoulder', 'left_elbow', 'right_elbow', 
                    'left_wrist', 'right_wrist', 'nose']
    
    for sample_idx in range(n_samples):
        for feature_idx in range(7):  # 7 landmark
            # Orijinal hareket verisi
            movement = X_data[sample_idx, :, feature_idx]
            
            # Velocity hesapla
            velocity = calculate_velocity(movement)
            
            # Acceleration hesapla
            acceleration = calculate_acceleration(velocity)
            
            # Jerk hesapla
            jerk = calculate_jerk(acceleration)
            
            # 21 özellik array'ine yerleştir
            base_idx = feature_idx * 3
            X_expanded[sample_idx, :, base_idx] = movement      # Orijinal hareket
            X_expanded[sample_idx, :, base_idx + 1] = velocity  # Velocity
            X_expanded[sample_idx, :, base_idx + 2] = acceleration  # Acceleration
            # Jerk'i kullanmıyoruz, sadece 21 özellik için placeholder
    
    print(f"   Output shape: {X_expanded.shape}")
    print("✅ Özellik genişletme tamamlandı!")
    
    return X_expanded

def main():
    """Ana fonksiyon"""
    print("🚀 EXTERNAL TEST - FEATURE EXPANSION TO 21")
    print("="*50)
    
    # Mevcut 7 özellikli veriyi yükle
    print("📊 Mevcut external test verilerini yüklüyor...")
    try:
        X_test_7 = np.load('/home/ubuntu/external_test_features.npy')
        y_test = np.load('/home/ubuntu/external_test_labels.npy')
        
        print(f"✅ Veriler yüklendi:")
        print(f"   X_test_7 shape: {X_test_7.shape}")
        print(f"   y_test shape: {y_test.shape}")
        
    except Exception as e:
        print(f"❌ Veri yükleme hatası: {e}")
        return
    
    # 21 özelliğe genişlet
    X_test_21 = expand_features_to_21(X_test_7)
    
    # Genişletilmiş veriyi kaydet
    print("\n💾 Genişletilmiş veriler kaydediliyor...")
    np.save('/home/ubuntu/external_test_features_21.npy', X_test_21)
    np.save('/home/ubuntu/external_test_labels_21.npy', y_test)
    
    print("✅ 21 özellikli external test verileri kaydedildi!")
    print("📁 Kaydedilen dosyalar:")
    print("   - external_test_features_21.npy")
    print("   - external_test_labels_21.npy")
    
    # Özet istatistikler
    print(f"\n📈 GENİŞLETİLMİŞ VERİ ÖZETİ:")
    print(f"   Shape: {X_test_21.shape}")
    print(f"   Autism samples: {np.sum(y_test)}")
    print(f"   Healthy samples: {len(y_test) - np.sum(y_test)}")
    
    # Özellik istatistikleri
    print(f"\n📊 ÖZELLİK İSTATİSTİKLERİ (21 özellik):")
    feature_names = ['left_shoulder', 'right_shoulder', 'left_elbow', 'right_elbow', 
                    'left_wrist', 'right_wrist', 'nose']
    feature_types = ['movement', 'velocity', 'acceleration']
    
    for i, name in enumerate(feature_names):
        for j, ftype in enumerate(feature_types):
            feature_idx = i * 3 + j
            feature_data = X_test_21[:, :, feature_idx].flatten()
            print(f"   {name}_{ftype}: mean={np.mean(feature_data):.6f}, std={np.std(feature_data):.6f}")

if __name__ == "__main__":
    main()

