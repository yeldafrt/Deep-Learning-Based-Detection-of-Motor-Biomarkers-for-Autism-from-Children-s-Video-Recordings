#!/usr/bin/env python3
"""
Threshold Optimization for Autism Detection
Farklı threshold değerleri ile autism detection rate'i optimize eder
"""

import numpy as np
import matplotlib.pyplot as plt

def load_predictions():
    """Önceki tahminleri yükle"""
    print("📊 Önceki tahmin sonuçlarını yüklüyor...")
    
    try:
        # Autism-only test tahminlerini yükle
        ensemble_pred = np.load('/home/ubuntu/autism_only_ensemble_predictions.npy')
        
        print(f"✅ Tahminler yüklendi:")
        print(f"   Ensemble predictions shape: {ensemble_pred.shape}")
        print(f"   Prediction range: [{np.min(ensemble_pred):.3f}, {np.max(ensemble_pred):.3f}]")
        print(f"   Mean prediction: {np.mean(ensemble_pred):.3f}")
        
        return ensemble_pred
        
    except Exception as e:
        print(f"❌ Tahmin yükleme hatası: {e}")
        return None

def optimize_threshold(predictions):
    """Farklı threshold değerleri ile optimize et"""
    print("🎯 Threshold optimization başlıyor...")
    
    # Test edilecek threshold değerleri
    thresholds = np.arange(0.1, 0.9, 0.05)
    
    results = []
    
    print("   Threshold değerleri test ediliyor...")
    for threshold in thresholds:
        # Binary tahminler
        binary_pred = (predictions > threshold).astype(int)
        
        # Autism detection rate (tüm örnekler autism olmalı)
        autism_detection_rate = np.mean(binary_pred)
        
        # Confidence statistics
        detected_confidences = predictions[binary_pred.flatten() == 1]
        missed_confidences = predictions[binary_pred.flatten() == 0]
        
        results.append({
            'threshold': threshold,
            'autism_detection_rate': autism_detection_rate,
            'detected_count': np.sum(binary_pred),
            'missed_count': len(binary_pred) - np.sum(binary_pred),
            'mean_detected_conf': np.mean(detected_confidences) if len(detected_confidences) > 0 else 0,
            'mean_missed_conf': np.mean(missed_confidences) if len(missed_confidences) > 0 else 0
        })
        
        print(f"      Threshold {threshold:.2f}: Detection Rate = {autism_detection_rate:.3f} ({autism_detection_rate*100:.1f}%)")
    
    return results

def find_optimal_threshold(results):
    """En iyi threshold'u bul"""
    print("\n🔍 En iyi threshold aranıyor...")
    
    # En yüksek detection rate'i bul
    best_result = max(results, key=lambda x: x['autism_detection_rate'])
    
    print(f"✅ En iyi threshold bulundu:")
    print(f"   Threshold: {best_result['threshold']:.2f}")
    print(f"   Autism Detection Rate: {best_result['autism_detection_rate']:.4f} ({best_result['autism_detection_rate']*100:.2f}%)")
    print(f"   Detected: {best_result['detected_count']}/39 autism videos")
    print(f"   Missed: {best_result['missed_count']}/39 autism videos")
    
    return best_result

def create_threshold_visualization(results):
    """Threshold optimization sonuçlarını görselleştir"""
    print("📈 Threshold optimization sonuçları görselleştiriliyor...")
    
    thresholds = [r['threshold'] for r in results]
    detection_rates = [r['autism_detection_rate'] * 100 for r in results]
    
    # En iyi threshold'u bul
    best_idx = np.argmax(detection_rates)
    best_threshold = thresholds[best_idx]
    best_rate = detection_rates[best_idx]
    
    # Grafik oluştur
    fig, ax = plt.subplots(1, 1, figsize=(12, 8), dpi=300)
    
    # Line plot
    line = ax.plot(thresholds, detection_rates, 'b-', linewidth=3, label='Autism Detection Rate')
    
    # En iyi noktayı işaretle
    ax.plot(best_threshold, best_rate, 'ro', markersize=12, label=f'Optimal Threshold = {best_threshold:.2f}')
    
    # Mevcut threshold'u işaretle (0.5)
    current_rate = detection_rates[10]  # 0.5 threshold yaklaşık 10. index
    ax.plot(0.5, current_rate, 'go', markersize=10, label=f'Current Threshold = 0.50')
    
    # Grafik ayarları
    ax.set_xlabel('Threshold Value', fontsize=14, fontweight='bold')
    ax.set_ylabel('Autism Detection Rate (%)', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=12, loc='upper right')
    
    # Y ekseni formatı
    ax.set_ylim(0, 105)
    ax.set_yticks(range(0, 101, 10))
    
    # X ekseni formatı
    ax.set_xlim(0.1, 0.85)
    ax.set_xticks(np.arange(0.1, 0.9, 0.1))
    
    # Annotation
    ax.annotate(f'Best: {best_rate:.1f}% at {best_threshold:.2f}', 
                xy=(best_threshold, best_rate), 
                xytext=(best_threshold + 0.15, best_rate + 10),
                arrowprops=dict(arrowstyle='->', color='red', lw=2),
                fontsize=12, fontweight='bold', color='red')
    
    # Layout ayarları
    plt.tight_layout()
    
    # Kaydet
    output_path = '/home/ubuntu/threshold_optimization_results.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print(f"✅ Grafik kaydedildi: {output_path}")
    return output_path

def save_optimization_results(results, best_result):
    """Optimization sonuçlarını kaydet"""
    print("💾 Threshold optimization sonuçları kaydediliyor...")
    
    with open('/home/ubuntu/threshold_optimization_detailed.txt', 'w') as f:
        f.write("THRESHOLD OPTIMIZATION RESULTS\n")
        f.write("="*50 + "\n\n")
        
        f.write("OPTIMAL THRESHOLD:\n")
        f.write(f"  Threshold: {best_result['threshold']:.2f}\n")
        f.write(f"  Autism Detection Rate: {best_result['autism_detection_rate']:.4f} ({best_result['autism_detection_rate']*100:.2f}%)\n")
        f.write(f"  Detected Videos: {best_result['detected_count']}/39\n")
        f.write(f"  Missed Videos: {best_result['missed_count']}/39\n")
        f.write(f"  Mean Confidence (Detected): {best_result['mean_detected_conf']:.3f}\n")
        f.write(f"  Mean Confidence (Missed): {best_result['mean_missed_conf']:.3f}\n\n")
        
        f.write("ALL THRESHOLD RESULTS:\n")
        f.write("-" * 30 + "\n")
        f.write("Threshold | Detection Rate | Detected | Missed\n")
        f.write("-" * 45 + "\n")
        
        for result in results:
            f.write(f"   {result['threshold']:.2f}   |     {result['autism_detection_rate']*100:5.1f}%     |    {result['detected_count']:2d}    |   {result['missed_count']:2d}\n")
    
    print("✅ Detaylı threshold optimization sonuçları kaydedildi!")

def apply_optimal_threshold(predictions, optimal_threshold):
    """Optimal threshold ile yeni sonuçlar üret"""
    print(f"🎯 Optimal threshold ({optimal_threshold:.2f}) uygulanıyor...")
    
    # Yeni binary tahminler
    optimized_binary = (predictions > optimal_threshold).astype(int)
    
    # Sonuçları kaydet
    np.save('/home/ubuntu/autism_only_optimized_binary.npy', optimized_binary)
    
    # İstatistikler
    detection_rate = np.mean(optimized_binary)
    detected_count = np.sum(optimized_binary)
    
    print(f"✅ Optimal threshold uygulandı:")
    print(f"   New Detection Rate: {detection_rate:.4f} ({detection_rate*100:.2f}%)")
    print(f"   Detected Videos: {detected_count}/39")
    
    return optimized_binary, detection_rate

def main():
    """Ana fonksiyon"""
    print("🚀 THRESHOLD OPTIMIZATION FOR AUTISM DETECTION")
    print("="*60)
    
    # Önceki tahminleri yükle
    predictions = load_predictions()
    if predictions is None:
        return
    
    # Threshold optimization yap
    results = optimize_threshold(predictions)
    
    # En iyi threshold'u bul
    best_result = find_optimal_threshold(results)
    
    # Sonuçları görselleştir
    graph_path = create_threshold_visualization(results)
    
    # Detaylı sonuçları kaydet
    save_optimization_results(results, best_result)
    
    # Optimal threshold'u uygula
    optimized_binary, final_rate = apply_optimal_threshold(predictions, best_result['threshold'])
    
    # Özet yazdır
    print("\n🎉 THRESHOLD OPTIMIZATION TAMAMLANDI!")
    print("="*60)
    print(f"📊 SONUÇLAR:")
    print(f"   Original Threshold (0.50): 46.15%")
    print(f"   Optimal Threshold ({best_result['threshold']:.2f}): {final_rate*100:.2f}%")
    print(f"   İyileştirme: +{final_rate*100 - 46.15:.2f} percentage points")
    print(f"📈 Grafik: {graph_path}")
    print(f"📄 Detaylı sonuçlar: /home/ubuntu/threshold_optimization_detailed.txt")

if __name__ == "__main__":
    main()

