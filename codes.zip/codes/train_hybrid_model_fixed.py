import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Dense, LSTM, Bidirectional, Dropout, Conv1D
from tensorflow.keras.layers import MaxPooling1D, Flatten, Concatenate, TimeDistributed, Attention
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import plot_model
import matplotlib.pyplot as plt
import os
import pickle

# Sonuçların kaydedileceği dizini oluştur
os.makedirs('/home/ubuntu/advanced_model/models', exist_ok=True)
os.makedirs('/home/ubuntu/advanced_model/results', exist_ok=True)

# Veriyi yükleme
X_train = np.load('/home/ubuntu/advanced_model/X_train_advanced.npy')
X_test = np.load('/home/ubuntu/advanced_model/X_test_advanced.npy')
y_train = np.load('/home/ubuntu/advanced_model/y_train_advanced.npy')
y_test = np.load('/home/ubuntu/advanced_model/y_test_advanced.npy')

print(f"Eğitim seti boyutu: {X_train.shape}")
print(f"Test seti boyutu: {X_test.shape}")
print(f"Eğitim seti sınıf dağılımı: {np.bincount(y_train)}")
print(f"Test seti sınıf dağılımı: {np.bincount(y_test)}")

# Model parametreleri
sequence_length = X_train.shape[1]  # 100
n_features = X_train.shape[2]       # 21
n_classes = 1                       # Binary sınıflandırma

# Hibrit BiLSTM+CNN+Attention modeli
def create_bilstm_cnn_attention_model():
    # Giriş katmanı
    input_layer = Input(shape=(sequence_length, n_features))
    
    # CNN yolu
    conv1 = Conv1D(filters=64, kernel_size=3, padding='same', activation='relu')(input_layer)
    conv2 = Conv1D(filters=64, kernel_size=5, padding='same', activation='relu')(input_layer)
    conv3 = Conv1D(filters=64, kernel_size=7, padding='same', activation='relu')(input_layer)
    
    # CNN çıktılarını birleştirme
    conv_concat = Concatenate()([conv1, conv2, conv3])
    # Zaman boyutunu korumak için pool_size=1 kullanıyoruz
    conv_pool = MaxPooling1D(pool_size=1)(conv_concat)
    conv_dropout = Dropout(0.3)(conv_pool)
    
    # BiLSTM yolu
    bilstm1 = Bidirectional(LSTM(64, return_sequences=True))(input_layer)
    bilstm_dropout1 = Dropout(0.3)(bilstm1)
    bilstm2 = Bidirectional(LSTM(32, return_sequences=True))(bilstm_dropout1)
    bilstm_dropout2 = Dropout(0.3)(bilstm2)
    
    # Attention mekanizması
    attention_layer = tf.keras.layers.MultiHeadAttention(
        num_heads=4, key_dim=16
    )(bilstm_dropout2, bilstm_dropout2)
    attention_add = tf.keras.layers.Add()([attention_layer, bilstm_dropout2])
    attention_norm = tf.keras.layers.LayerNormalization()(attention_add)
    
    # CNN ve BiLSTM+Attention yollarını birleştirme
    # Şimdi her iki yolun da zaman boyutu aynı (sequence_length)
    concat_layer = Concatenate()([conv_dropout, attention_norm])
    
    # Zaman boyutunu düzleştirme
    flatten_layer = TimeDistributed(Flatten())(concat_layer)
    
    # Global özellikleri çıkarma
    global_max_pool = tf.keras.layers.GlobalMaxPooling1D()(flatten_layer)
    global_avg_pool = tf.keras.layers.GlobalAveragePooling1D()(flatten_layer)
    
    # Özellikleri birleştirme
    concat_global = Concatenate()([global_max_pool, global_avg_pool])
    
    # Tam bağlantılı katmanlar
    dense1 = Dense(64, activation='relu')(concat_global)
    dropout1 = Dropout(0.4)(dense1)
    dense2 = Dense(32, activation='relu')(dropout1)
    dropout2 = Dropout(0.3)(dense2)
    
    # Çıkış katmanı
    output_layer = Dense(n_classes, activation='sigmoid')(dropout2)
    
    # Model oluşturma
    model = Model(inputs=input_layer, outputs=output_layer)
    
    # Model derleme
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', 
                 tf.keras.metrics.Precision(name='precision'),
                 tf.keras.metrics.Recall(name='recall'),
                 tf.keras.metrics.AUC(name='auc')]
    )
    
    return model

# GRU tabanlı model (ensemble için)
def create_gru_model():
    model = Sequential([
        Input(shape=(sequence_length, n_features)),
        Bidirectional(tf.keras.layers.GRU(64, return_sequences=True)),
        Dropout(0.3),
        Bidirectional(tf.keras.layers.GRU(32)),
        Dropout(0.3),
        Dense(16, activation='relu'),
        Dropout(0.2),
        Dense(n_classes, activation='sigmoid')
    ])
    
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', 
                 tf.keras.metrics.Precision(name='precision'),
                 tf.keras.metrics.Recall(name='recall'),
                 tf.keras.metrics.AUC(name='auc')]
    )
    
    return model

# CNN tabanlı model (ensemble için)
def create_cnn_model():
    model = Sequential([
        Input(shape=(sequence_length, n_features)),
        Conv1D(filters=64, kernel_size=3, padding='same', activation='relu'),
        MaxPooling1D(pool_size=2),
        Conv1D(filters=128, kernel_size=3, padding='same', activation='relu'),
        MaxPooling1D(pool_size=2),
        Conv1D(filters=128, kernel_size=3, padding='same', activation='relu'),
        GlobalMaxPooling1D(),
        Dense(64, activation='relu'),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dropout(0.2),
        Dense(n_classes, activation='sigmoid')
    ])
    
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', 
                 tf.keras.metrics.Precision(name='precision'),
                 tf.keras.metrics.Recall(name='recall'),
                 tf.keras.metrics.AUC(name='auc')]
    )
    
    return model

# Callback'ler
early_stopping = EarlyStopping(
    monitor='val_loss',
    patience=15,
    restore_best_weights=True,
    verbose=1
)

reduce_lr = ReduceLROnPlateau(
    monitor='val_loss',
    factor=0.5,
    patience=5,
    min_lr=0.00001,
    verbose=1
)

# Modelleri oluşturma
print("Hibrit BiLSTM+CNN+Attention modeli oluşturuluyor...")
bilstm_cnn_attention_model = create_bilstm_cnn_attention_model()
bilstm_cnn_attention_model.summary()

print("GRU modeli oluşturuluyor...")
gru_model = create_gru_model()
gru_model.summary()

print("CNN modeli oluşturuluyor...")
cnn_model = create_cnn_model()
cnn_model.summary()

# Modelleri eğitme
print("Hibrit BiLSTM+CNN+Attention modeli eğitiliyor...")
bilstm_cnn_attention_history = bilstm_cnn_attention_model.fit(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    validation_split=0.2,
    callbacks=[early_stopping, reduce_lr],
    verbose=1
)

print("GRU modeli eğitiliyor...")
gru_history = gru_model.fit(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    validation_split=0.2,
    callbacks=[early_stopping, reduce_lr],
    verbose=1
)

print("CNN modeli eğitiliyor...")
cnn_history = cnn_model.fit(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    validation_split=0.2,
    callbacks=[early_stopping, reduce_lr],
    verbose=1
)

# Modelleri kaydetme
bilstm_cnn_attention_model.save('/home/ubuntu/advanced_model/models/bilstm_cnn_attention_model.h5')
gru_model.save('/home/ubuntu/advanced_model/models/gru_model.h5')
cnn_model.save('/home/ubuntu/advanced_model/models/cnn_model.h5')

# Eğitim geçmişini kaydetme
with open('/home/ubuntu/advanced_model/results/bilstm_cnn_attention_history.pkl', 'wb') as f:
    pickle.dump(bilstm_cnn_attention_history.history, f)

with open('/home/ubuntu/advanced_model/results/gru_history.pkl', 'wb') as f:
    pickle.dump(gru_history.history, f)

with open('/home/ubuntu/advanced_model/results/cnn_history.pkl', 'wb') as f:
    pickle.dump(cnn_history.history, f)

# Ensemble tahminleri
print("Ensemble tahminleri oluşturuluyor...")
bilstm_cnn_attention_pred = bilstm_cnn_attention_model.predict(X_test)
gru_pred = gru_model.predict(X_test)
cnn_pred = cnn_model.predict(X_test)

# Ağırlıklı ensemble (en iyi performans gösteren modele daha yüksek ağırlık)
ensemble_pred = (0.5 * bilstm_cnn_attention_pred + 0.3 * gru_pred + 0.2 * cnn_pred)
ensemble_pred_binary = (ensemble_pred > 0.5).astype(int).flatten()

# Ensemble sonuçlarını kaydetme
np.save('/home/ubuntu/advanced_model/results/ensemble_pred.npy', ensemble_pred)
np.save('/home/ubuntu/advanced_model/results/ensemble_pred_binary.npy', ensemble_pred_binary)
np.save('/home/ubuntu/advanced_model/results/y_test.npy', y_test)

print("Hibrit model eğitimi ve ensemble tahminleri tamamlandı.")
