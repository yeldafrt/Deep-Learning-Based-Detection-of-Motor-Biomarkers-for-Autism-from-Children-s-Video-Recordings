import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
import os

# Veri setlerini yükleme
otizm_df = pd.read_csv('/home/ubuntu/upload/40_kare_bazli_pose_ozellikleri_otizm_fsm.csv')
saglikli_df = pd.read_csv('/home/ubuntu/upload/40_kare_bazli_pose_ozellikleri_saglikli_fsm.csv')

# Etiket ekleme
otizm_df['label'] = 1  # 1: Otizm
saglikli_df['label'] = 0  # 0: Sağlıklı

# Veri setlerini birleştirme
combined_df = pd.concat([otizm_df, saglikli_df], ignore_index=True)

# Veri seti hakkında bilgi
print("Veri seti boyutu:", combined_df.shape)
print("Sütunlar:", combined_df.columns.tolist())
print("Otizm etiketli veri sayısı:", len(otizm_df))
print("Sağlıklı etiketli veri sayısı:", len(saglikli_df))

# Eksik değerleri kontrol etme
print("Eksik değerler:", combined_df.isnull().sum().sum())

# Eksik değerleri doldurma (varsa)
combined_df = combined_df.fillna(0)

# Sonuçların kaydedileceği dizini oluştur
os.makedirs('/home/ubuntu/advanced_model', exist_ok=True)

# Veri setini kaydetme
combined_df.to_csv('/home/ubuntu/advanced_model/combined_pose_features.csv', index=False)

print("Veri ön işleme ve birleştirme tamamlandı.")
